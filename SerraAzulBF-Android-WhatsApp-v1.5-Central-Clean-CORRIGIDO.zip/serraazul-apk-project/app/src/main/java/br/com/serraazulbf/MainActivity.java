package br.com.serraazulbf;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewFeature;

public class MainActivity extends AppCompatActivity {
    private static final String APP_URL = "https://ngcyuri.github.io/serra-azul-bf/";
    private WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(false);
        s.setTextZoom(100);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setUserAgentString(s.getUserAgentString() + " SerraAzulBF-Android/1.4");

        if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            WebSettingsCompat.setForceDark(s, WebSettingsCompat.FORCE_DARK_OFF);
        }

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new WhatsAppBridge(), "SerraAzulAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost();
                if (host != null && (host.equals("ngcyuri.github.io") || host.endsWith("supabase.co") || host.endsWith("supabase.com"))) {
                    return false;
                }
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                injectAppOnlyMobileStyle(view);
            }
        });

        webView.loadUrl(APP_URL);

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack(); else finish();
            }
        });
    }

    /**
     * Ajustes exclusivos do APK. O site publicado no GitHub Pages não é alterado.
     * A tabela de Consertos e Solicitações vira cartão no celular, eliminando
     * a rolagem horizontal e os cabeçalhos cortados.
     */
    private void injectAppOnlyMobileStyle(WebView view) {
        String css = ""
            + "@media (max-width:760px){"
            + "html,body{max-width:100%!important;overflow-x:hidden!important;}"
            + "#fullscreen-btn{display:none!important;}"
            + "header.canva-header{padding:10px 12px!important;}"
            + "header.canva-header>.mx-auto{display:flex!important;align-items:center!important;gap:10px!important;flex-wrap:nowrap!important;}"
            + "header.canva-header .brand-title{display:flex!important;align-items:center!important;gap:10px!important;flex:1 1 auto!important;min-width:0!important;}"
            + "header.canva-header .brand-logo{width:105px!important;max-width:105px!important;height:auto!important;max-height:58px!important;object-fit:contain!important;flex:0 0 auto!important;}"
            + "header.canva-header [data-template-id='page-title']{font-size:18px!important;line-height:1.15!important;letter-spacing:-.02em!important;word-break:normal!important;overflow-wrap:normal!important;margin:0!important;}"
            + "header.canva-header [data-template-id='page-subtitle']{display:none!important;}"
            + "header.canva-header .header-actions{width:auto!important;flex:0 0 auto!important;margin:0!important;}"
            + "#user-area{display:flex!important;align-items:center!important;gap:6px!important;}"
            + "#user-badge{max-width:180px!important;padding:7px 9px!important;}"
            + "#user-email{font-size:11px!important;max-width:112px!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important;}"
            + "#user-role{display:none!important;}"
            + "#logout-btn{padding:8px 9px!important;font-size:12px!important;}"
            + "main.mx-auto.max-w-7xl{padding:12px!important;gap:0!important;}"
            + "#tabs-container{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:8px!important;margin-bottom:12px!important;}"
            + "#tabs-container>button{width:100%!important;min-width:0!important;min-height:44px!important;justify-content:center!important;padding:9px 8px!important;font-size:12px!important;line-height:1.2!important;}"
            + "#tabs-container>button[data-month]{font-size:13px!important;min-height:46px!important;border-radius:12px!important;}"
            + "#tabs-container>button[data-month].tab-active{box-shadow:0 2px 8px rgba(15,23,42,.08)!important;}"
            + "#tabs-container>button[data-template-id='new-month-btn'],#tabs-container>button[data-template-id='edit-month-btn'],#tabs-container>button[data-template-id='suppliers-btn'],#tabs-container>button[data-template-id='users-btn'],#tabs-container>button[data-template-id='history-btn']{font-size:11px!important;}"
            + "#summary-cards{display:none!important;margin:0 0 12px!important;gap:8px!important;}"
            + "#summary-cards.android-month-open{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;}"
            + "#summary-cards .card-stat{padding:10px!important;border-width:1px!important;border-radius:12px!important;box-shadow:none!important;}"
            + "#summary-cards .card-stat p:first-child{font-size:9px!important;letter-spacing:.08em!important;}"
            + "#summary-cards .card-stat p:last-child{font-size:21px!important;margin-top:2px!important;}"
            + "#summary-cards::before{content:'Indicadores do mês';grid-column:1/-1;font-size:10px;font-weight:800;color:#64748b;text-transform:uppercase;letter-spacing:.08em;margin:0 2px;}"
            + "#tabs-container::before{content:'Mês e módulos';grid-column:1/-1;font-size:10px;font-weight:800;color:#64748b;text-transform:uppercase;letter-spacing:.08em;margin:0 2px;}"
            + "#sync-status{font-size:10px!important;}"
            + "#sync-status button{font-size:10px!important;}"
            + "#requests-modal .modal-panel,#repairs-modal .modal-panel,#request-form-modal .modal-panel,#repair-form-modal .modal-panel,#repair-detail-modal .modal-panel{width:calc(100vw - 20px)!important;max-width:none!important;padding:14px!important;}"
            + "#requests-modal .mb-5.grid,#repairs-modal .mb-5.grid{grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:8px!important;}"
            + "#requests-modal .mb-4.flex,#repairs-modal .mb-4.grid{grid-template-columns:1fr!important;gap:8px!important;}"
            + "#requests-modal .mb-4.flex>* ,#repairs-modal .mb-4.grid>*{width:100%!important;min-width:0!important;}"
            + "#requests-modal table,#repairs-modal table{width:100%!important;min-width:0!important;border-collapse:separate!important;}"
            + "#requests-modal thead,#repairs-modal thead{display:none!important;}"
            + "#requests-modal #requests-body,#repairs-modal #repairs-body{display:block!important;width:100%!important;}"
            + "#requests-modal #requests-body tr,#repairs-modal #repairs-body tr{display:block!important;width:100%!important;margin:0 0 10px!important;padding:10px 12px!important;border:1px solid #e2e8f0!important;border-radius:13px!important;background:#fff!important;box-shadow:0 2px 8px rgba(15,23,42,.05)!important;}"
            + "#requests-modal #requests-body td,#repairs-modal #repairs-body td{display:flex!important;align-items:flex-start!important;justify-content:space-between!important;gap:8px!important;width:100%!important;padding:6px 0!important;border:0!important;text-align:right!important;font-size:12px!important;line-height:1.35!important;white-space:normal!important;word-break:break-word!important;}"
            + "#requests-modal #requests-body td:before,#repairs-modal #repairs-body td:before{flex:0 0 38%!important;text-align:left!important;color:#64748b!important;font-size:9px!important;font-weight:800!important;text-transform:uppercase!important;letter-spacing:.04em!important;}"
            + "#requests-modal #requests-body td:nth-child(1):before{content:'Data'}"
            + "#requests-modal #requests-body td:nth-child(2):before{content:'Produto / Material'}"
            + "#requests-modal #requests-body td:nth-child(3):before{content:'Código Protheus'}"
            + "#requests-modal #requests-body td:nth-child(4):before{content:'Quantidade'}"
            + "#requests-modal #requests-body td:nth-child(5):before{content:'Solicitante'}"
            + "#requests-modal #requests-body td:nth-child(6):before{content:'Status'}"
            + "#requests-modal #requests-body td:nth-child(7){justify-content:flex-end!important;margin-top:4px!important;padding-top:8px!important;border-top:1px solid #f1f5f9!important;}"
            + "#requests-modal #requests-body td:nth-child(7):before{display:none!important;}"
            + "#repairs-modal #repairs-body td:nth-child(1):before{content:'Envio'}"
            + "#repairs-modal #repairs-body td:nth-child(2):before{content:'Mercadoria'}"
            + "#repairs-modal #repairs-body td:nth-child(3):before{content:'Fornecedor'}"
            + "#repairs-modal #repairs-body td:nth-child(4):before{content:'NF saída'}"
            + "#repairs-modal #repairs-body td:nth-child(5):before{content:'Responsável'}"
            + "#repairs-modal #repairs-body td:nth-child(6):before{content:'Status'}"
            + "#repairs-modal #repairs-body td:nth-child(7):before{content:'Dias fora'}"
            + "#repairs-modal #repairs-body td:nth-child(8):before{content:'Ações'}"
            + "#repairs-modal #repairs-body td:last-child{justify-content:flex-end!important;margin-top:4px!important;padding-top:8px!important;border-top:1px solid #f1f5f9!important;}"
            + "#request-form-modal input,#request-form-modal select,#request-form-modal textarea,#repair-form-modal input,#repair-form-modal select,#repair-form-modal textarea{min-height:46px!important;font-size:16px!important;max-width:100%!important;}"
            + "#request-form-modal textarea,#repair-form-modal textarea{min-height:88px!important;}"
            + "}"
            + "@media (prefers-reduced-motion: reduce){*{transition:none!important;scroll-behavior:auto!important;}}";

        String encoded = Base64.encodeToString(css.getBytes(java.nio.charset.StandardCharsets.UTF_8), Base64.NO_WRAP);
        String js = "(function(){try{"
            + "var id='serra-azul-bf-android-mobile-css';"
            + "var old=document.getElementById(id);if(old)old.remove();"
            + "var s=document.createElement('style');s.id=id;s.textContent=atob('" + encoded + "');document.head.appendChild(s);"
            + "document.documentElement.classList.add('serra-azul-bf-android');"
            + "var summary=document.getElementById('summary-cards');"
            + "function bindMonths(){"
            + "document.querySelectorAll('#tabs-container button[data-month]').forEach(function(btn){"
            + "if(btn.dataset.androidBound==='1')return;btn.dataset.androidBound='1';"
            + "btn.addEventListener('click',function(){"
            + "if(summary){summary.classList.remove('android-month-open');void summary.offsetWidth;summary.classList.add('android-month-open');}"
            + "});"
            + "});"
            + "}"
            + "if(summary)summary.classList.remove('android-month-open');"
            + "bindMonths();"
            + "var tabs=document.getElementById('tabs-container');"
            + "if(tabs&&!tabs.dataset.androidObserver){tabs.dataset.androidObserver='1';new MutationObserver(function(){bindMonths();}).observe(tabs,{childList:true,subtree:true});}"
            + "function addWhatsApp(){"
            + "var body=document.querySelector('#requests-modal #requests-body');if(!body)return;"
            + "body.querySelectorAll('tr').forEach(function(tr){"
            + "var td=tr.querySelectorAll('td');if(td.length<7)return;"
            + "var status=(td[5].innerText||'').trim();"
            + "if(!/^(Em andamento|Atendida|Finalizada)$/i.test(status))return;"
            + "var action=td[6];if(action.querySelector('.android-wa-btn'))return;"
            + "var val=function(i){return td[i]?(td[i].innerText||'').trim():''};"
            + "var msg='📦 SOLICITAÇÃO\\n\\nProduto: '+val(1)+'\\nCódigo Protheus: '+val(2)+'\\nQuantidade: '+val(3)+'\\nSolicitante: '+val(4)+'\\nData: '+val(0)+'\\n\\n⚠️ Solicitação em andamento. Favor realizar o pedido no TOTVS.';"
            + "var b=document.createElement('button');b.className='android-wa-btn';b.type='button';b.textContent='📱 WhatsApp';"
            + "b.style.cssText='margin-left:6px;min-height:40px;padding:8px 10px;border:1px solid #16a34a;border-radius:9px;background:#f0fdf4;color:#15803d;font-weight:800;cursor:pointer;';"
            + "b.onclick=function(e){e.preventDefault();e.stopPropagation();if(window.SerraAzulAndroid)window.SerraAzulAndroid.sendWhatsApp(msg);};"
            + "action.appendChild(b);"
            + "});"
            + "}"
            + "addWhatsApp();"
            + "var req=document.getElementById('requests-modal');"
            + "if(req&&!req.dataset.androidObserver){req.dataset.androidObserver='1';new MutationObserver(function(){addWhatsApp();}).observe(req,{childList:true,subtree:true});}"
            + "}catch(e){console.log('SerraAzul Android UI:',e);}})();";
        view.evaluateJavascript(js, null);
    }

    /** Ponte nativa usada somente pelo APK para abrir o compartilhamento do WhatsApp. */
    private class WhatsAppBridge {
        @JavascriptInterface
        public void sendWhatsApp(String message) {
            runOnUiThread(() -> {
                try {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_TEXT, message == null ? "" : message);
                    Intent chooser = Intent.createChooser(send, "Enviar solicitação pelo WhatsApp");
                    startActivity(chooser);
                } catch (Exception ignored) {
                    try {
                        Uri uri = Uri.parse("https://wa.me/?text=" + Uri.encode(message == null ? "" : message));
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (Exception ignored2) {}
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }
}
