package br.com.serraazulbf;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewFeature;

public class MainActivity extends AppCompatActivity {
    private static final String APP_URL = "https://ngcyuri.github.io/serra-azul-bf/";
    private WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(false);
        s.setTextZoom(100);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setUserAgentString(s.getUserAgentString() + " SerraAzulBF-Android/1.6");

        if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            WebSettingsCompat.setForceDark(s, WebSettingsCompat.FORCE_DARK_OFF);
        }

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new WhatsAppBridge(), "SerraAzulAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost();
                if (host != null && (host.equals("ngcyuri.github.io") || host.endsWith("supabase.co") || host.endsWith("supabase.com"))) {
                    return false;
                }
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                injectAppOnlyMobileStyle(view);
            }
        });

        webView.loadUrl(APP_URL);

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack(); else finish();
            }
        });
    }

    /**
     * Ajustes exclusivos do APK. O site publicado no GitHub Pages não é alterado.
     * A tabela de Consertos e Solicitações vira cartão no celular, eliminando
     * a rolagem horizontal e os cabeçalhos cortados.
     */
    private void injectAppOnlyMobileStyle(WebView view) {
        String css = ""
            + "@media (max-width:760px){"
            + "html,body{width:100%!important;max-width:100%!important;overflow-x:hidden!important;background:#f4f7fa!important;}"
            + "body{font-family:Arial,sans-serif!important;color:#17324d!important;}"
            + "#fullscreen-btn{display:none!important;}"
            + "#app-shell{background:#f4f7fa!important;}"
            + "header.canva-header{background:#fff!important;color:#17324d!important;box-shadow:none!important;border-bottom:1px solid #e5ebf1!important;padding:12px 14px!important;}"
            + "header.canva-header>.mx-auto{display:flex!important;align-items:center!important;gap:10px!important;max-width:none!important;}"
            + "header.canva-header .brand-title{display:flex!important;align-items:center!important;gap:10px!important;min-width:0!important;flex:1 1 auto!important;}"
            + "header.canva-header .brand-logo{width:92px!important;max-width:92px!important;height:auto!important;max-height:54px!important;object-fit:contain!important;flex:0 0 auto!important;}"
            + "header.canva-header [data-template-id='page-title']{font-size:19px!important;line-height:1.08!important;letter-spacing:-.02em!important;color:#17324d!important;word-break:normal!important;overflow-wrap:normal!important;margin:0!important;}"
            + "header.canva-header [data-template-id='page-subtitle']{display:none!important;}"
            + "header.canva-header .header-actions{flex:0 0 auto!important;margin:0!important;}"
            + "#user-area{display:flex!important;align-items:center!important;gap:6px!important;}"
            + "#user-badge{max-width:185px!important;padding:7px 9px!important;border:1px solid #dbe5ee!important;background:#fff!important;color:#17324d!important;box-shadow:0 1px 4px rgba(15,23,42,.04)!important;}"
            + "#user-email{font-size:11px!important;max-width:120px!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important;}"
            + "#user-role{display:none!important;}"
            + "#logout-btn{padding:8px 10px!important;font-size:12px!important;border:1px solid #dbe5ee!important;background:#fff!important;color:#17324d!important;}"
            + "main.mx-auto.max-w-7xl{max-width:none!important;padding:14px!important;background:#f4f7fa!important;}"
            + "#tabs-container{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:10px!important;margin:0!important;}"
            + "#tabs-container::before{content:'MÊS E MÓDULOS';grid-column:1/-1;font-size:11px;font-weight:800;color:#5d7894;letter-spacing:.08em;margin:4px 2px 0;}"
            + "#tabs-container>button{width:100%!important;min-width:0!important;min-height:52px!important;justify-content:center!important;padding:10px 9px!important;border-radius:14px!important;border:1px solid #dbe5ee!important;background:#fff!important;color:#17324d!important;box-shadow:0 2px 7px rgba(15,23,42,.04)!important;font-size:13px!important;}"
            + "#tabs-container>button[data-month]{min-height:58px!important;font-size:14px!important;font-weight:800!important;border-color:#d6e2ed!important;background:#fff!important;color:#58718a!important;}"
            + "#tabs-container>button[data-month].tab-active{background:#173b5f!important;color:#fff!important;border-color:#173b5f!important;box-shadow:0 5px 14px rgba(23,59,95,.18)!important;}"
            + "#tabs-container>button[data-template-id='new-month-btn'],#tabs-container>button[data-template-id='edit-month-btn'],#tabs-container>button[data-template-id='suppliers-btn'],#tabs-container>button[data-template-id='users-btn'],#tabs-container>button[data-template-id='history-btn']{font-size:12px!important;}"
            + "#tabs-container>button:nth-last-child(1){grid-column:1!important;}"
            + "#summary-cards{display:none!important;margin:18px 0 14px!important;gap:10px!important;}"
            + "#summary-cards.android-month-open{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;}"
            + "#summary-cards::before{content:'INDICADORES DO MÊS';grid-column:1/-1;font-size:11px;font-weight:800;color:#5d7894;letter-spacing:.08em;margin:0 2px 1px;}"
            + "#summary-cards .card-stat{padding:13px!important;border:1px solid #dbe5ee!important;border-radius:14px!important;background:#fff!important;box-shadow:0 2px 8px rgba(15,23,42,.04)!important;}"
            + "#summary-cards .card-stat p:first-child{font-size:9px!important;letter-spacing:.08em!important;color:#68809a!important;}"
            + "#summary-cards .card-stat p:last-child{font-size:24px!important;margin-top:2px!important;color:#102b45!important;}"
            + ".filter-grid{margin-top:14px!important;}"
            + ".filter-grid>div{min-width:0!important;width:100%!important;}"
            + ".filter-grid input,.filter-grid select{min-height:44px!important;font-size:15px!important;}"
            + "#orders-table{min-width:0!important;width:100%!important;}"
            + "#orders-table thead{display:none!important;}"
            + "#orders-body{display:block!important;width:100%!important;}"
            + "#orders-body tr{display:block!important;width:100%!important;margin:0 0 10px!important;padding:13px!important;border:1px solid #dbe5ee!important;border-radius:14px!important;background:#fff!important;box-shadow:0 2px 8px rgba(15,23,42,.04)!important;}"
            + "#orders-body td{display:flex!important;justify-content:space-between!important;gap:10px!important;width:100%!important;padding:6px 0!important;border:0!important;text-align:right!important;font-size:12px!important;white-space:normal!important;word-break:break-word!important;}"
            + "#orders-body td:before{flex:0 0 42%!important;text-align:left!important;color:#68809a!important;font-size:9px!important;font-weight:800!important;text-transform:uppercase!important;letter-spacing:.04em!important;}"
            + "#orders-body td:nth-child(1):before{content:'Fornecedor'}#orders-body td:nth-child(2):before{content:'Orçamento'}#orders-body td:nth-child(3):before{content:'Recebido'}#orders-body td:nth-child(4):before{content:'Pedido'}#orders-body td:nth-child(5):before{content:'Dia feito'}#orders-body td:nth-child(6):before{content:'Status'}"
            + "#orders-body td:last-child{justify-content:flex-end!important;margin-top:4px!important;padding-top:9px!important;border-top:1px solid #eef3f7!important;}#orders-body td:last-child:before{display:none!important;}"
            + ".modal-overlay{padding:0!important;align-items:stretch!important;justify-content:stretch!important;background:rgba(15,23,42,.34)!important;backdrop-filter:blur(3px)!important;}"
            + ".modal-overlay .modal-panel{width:100%!important;max-width:none!important;height:100dvh!important;max-height:100dvh!important;margin:0!important;border-radius:0!important;padding:16px!important;overflow:auto!important;box-shadow:none!important;background:#f7f9fb!important;}"
            + ".modal-overlay .modal-panel>div:first-child{position:sticky!important;top:-16px!important;z-index:5!important;margin:-16px -16px 14px!important;padding:14px 16px!important;background:rgba(255,255,255,.97)!important;border-bottom:1px solid #e1e8ef!important;}"
            + "#dashboard-modal .modal-panel,#reports-modal .modal-panel,#requests-modal .modal-panel,#repairs-modal .modal-panel,#users-modal .modal-panel,#suppliers-modal .modal-panel,#history-modal .modal-panel{background:#f4f7fa!important;}"
            + "#requests-modal .mb-5.grid,#repairs-modal .mb-5.grid{grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:8px!important;}"
            + "#requests-modal .mb-4.flex,#repairs-modal .mb-4.grid{grid-template-columns:1fr!important;gap:8px!important;}"
            + "#requests-modal .mb-4.flex>* ,#repairs-modal .mb-4.grid>*{width:100%!important;min-width:0!important;}"
            + "#requests-modal table,#repairs-modal table,#history-modal table,#suppliers-modal table,#users-modal table{width:100%!important;min-width:0!important;border-collapse:separate!important;border-spacing:0!important;}"
            + "#requests-modal thead,#repairs-modal thead,#history-modal thead,#suppliers-modal thead,#users-modal thead{display:none!important;}"
            + "#requests-modal #requests-body,#repairs-modal #repairs-body,#history-modal #history-body{display:block!important;width:100%!important;}"
            + "#requests-modal #requests-body tr,#repairs-modal #repairs-body tr,#history-modal #history-body tr,#suppliers-modal tbody tr,#users-modal tbody tr{display:block!important;width:100%!important;margin:0 0 10px!important;padding:12px!important;border:1px solid #dbe5ee!important;border-radius:14px!important;background:#fff!important;box-shadow:0 2px 8px rgba(15,23,42,.04)!important;}"
            + "#requests-modal #requests-body td,#repairs-modal #repairs-body td,#history-modal #history-body td,#suppliers-modal tbody td,#users-modal tbody td{display:flex!important;align-items:flex-start!important;justify-content:space-between!important;gap:8px!important;width:100%!important;padding:6px 0!important;border:0!important;text-align:right!important;font-size:12px!important;line-height:1.35!important;white-space:normal!important;word-break:break-word!important;}"
            + "#requests-modal #requests-body td:before,#repairs-modal #repairs-body td:before,#history-modal #history-body td:before,#suppliers-modal tbody td:before,#users-modal tbody td:before{flex:0 0 38%!important;text-align:left!important;color:#68809a!important;font-size:9px!important;font-weight:800!important;text-transform:uppercase!important;letter-spacing:.04em!important;}"
            + "#requests-modal #requests-body td:nth-child(1):before{content:'Data'}#requests-modal #requests-body td:nth-child(2):before{content:'Produto'}#requests-modal #requests-body td:nth-child(3):before{content:'Código Protheus'}#requests-modal #requests-body td:nth-child(4):before{content:'Quantidade'}#requests-modal #requests-body td:nth-child(5):before{content:'Solicitante'}#requests-modal #requests-body td:nth-child(6):before{content:'Status'}"
            + "#requests-modal #requests-body td:last-child,#repairs-modal #repairs-body td:last-child{justify-content:flex-end!important;margin-top:5px!important;padding-top:9px!important;border-top:1px solid #eef3f7!important;}#requests-modal #requests-body td:last-child:before,#repairs-modal #repairs-body td:last-child:before{display:none!important;}"
            + "#repairs-modal #repairs-body td:nth-child(1):before{content:'Envio'}#repairs-modal #repairs-body td:nth-child(2):before{content:'Mercadoria'}#repairs-modal #repairs-body td:nth-child(3):before{content:'Fornecedor'}#repairs-modal #repairs-body td:nth-child(4):before{content:'NF saída'}#repairs-modal #repairs-body td:nth-child(5):before{content:'Responsável'}#repairs-modal #repairs-body td:nth-child(6):before{content:'Status'}#repairs-modal #repairs-body td:nth-child(7):before{content:'NF retorno'}#repairs-modal #repairs-body td:nth-child(8):before{content:'Retorno'}#repairs-modal #repairs-body td:nth-child(9):before{content:'Dias fora'}"
            + "#history-modal #history-body td:nth-child(1):before{content:'Data/Hora'}#history-modal #history-body td:nth-child(2):before{content:'Usuário'}#history-modal #history-body td:nth-child(3):before{content:'Ação'}#history-modal #history-body td:nth-child(4):before{content:'Registro'}#history-modal #history-body td:nth-child(5):before{content:'Descrição'}"
            + "#request-form-modal input,#request-form-modal select,#request-form-modal textarea,#repair-form-modal input,#repair-form-modal select,#repair-form-modal textarea{min-height:46px!important;font-size:16px!important;max-width:100%!important;}"
            + "#request-form-modal textarea,#repair-form-modal textarea{min-height:90px!important;}"
            + ".android-wa-btn{min-height:40px!important;padding:8px 11px!important;border:1px solid #22c55e!important;border-radius:10px!important;background:#ecfdf5!important;color:#15803d!important;font-weight:800!important;box-shadow:none!important;}"
            + "#sync-status{position:fixed!important;left:14px!important;right:14px!important;bottom:12px!important;z-index:50!important;border-radius:18px!important;background:rgba(255,255,255,.96)!important;border:1px solid #dbe5ee!important;box-shadow:0 6px 24px rgba(15,23,42,.10)!important;padding:8px 10px!important;font-size:10px!important;}"
            + "#sync-status-message{font-size:10px!important;}"
            + "#realtime-status{font-size:10px!important;}"
            + "}")
            + "@media (min-width:761px){.serra-azul-bf-android{}}");

        String encoded = Base64.encodeToString(css.getBytes(java.nio.charset.StandardCharsets.UTF_8), Base64.NO_WRAP);
        String js = "(function(){try{"
            + "var id='serra-azul-bf-android-ui';var old=document.getElementById(id);if(old)old.remove();"
            + "var s=document.createElement('style');s.id=id;s.textContent=atob('" + encoded + "');document.head.appendChild(s);"
            + "document.documentElement.classList.add('serra-azul-bf-android');"
            + "var summary=document.getElementById('summary-cards');"
            + "function bindMonthButtons(){document.querySelectorAll('#tabs-container button[data-month]').forEach(function(b){if(b.dataset.androidMonth==='1')return;b.dataset.androidMonth='1';b.addEventListener('click',function(){setTimeout(function(){if(summary){summary.classList.add('android-month-open');summary.scrollIntoView({behavior:'smooth',block:'start'});}},120);});});}"
            + "if(summary)summary.classList.remove('android-month-open');bindMonthButtons();"
            + "var tabs=document.getElementById('tabs-container');if(tabs&&!tabs.dataset.androidWatch){tabs.dataset.androidWatch='1';new MutationObserver(function(){bindMonthButtons();}).observe(tabs,{childList:true,subtree:true});}"
            + "function addWhatsApp(){var body=document.querySelector('#requests-modal #requests-body');if(!body)return;body.querySelectorAll('tr').forEach(function(tr){var td=tr.querySelectorAll('td');if(td.length<7)return;var status=(td[5].innerText||'').trim();if(!/^(Em andamento|Atendida|Finalizada)$/i.test(status))return;var action=td[6];if(!action||action.querySelector('.android-wa-btn'))return;var val=function(i){return td[i]?(td[i].innerText||'').trim():''};var msg='SOLICITACAO\\n\\nProduto: '+val(1)+'\\nCodigo Protheus: '+val(2)+'\\nQuantidade: '+val(3)+'\\nSolicitante: '+val(4)+'\\nData: '+val(0)+'\\n\\nSolicitacao em andamento. Favor realizar o pedido no TOTVS.';var b=document.createElement('button');b.className='android-wa-btn';b.type='button';b.textContent='WhatsApp';b.onclick=function(e){e.preventDefault();e.stopPropagation();if(window.SerraAzulAndroid){window.SerraAzulAndroid.sendWhatsApp(msg);}else{window.open('https://wa.me/?text='+encodeURIComponent(msg),'_blank');}};action.appendChild(b);});}"
            + "addWhatsApp();var req=document.getElementById('requests-modal');if(req&&!req.dataset.androidWatch){req.dataset.androidWatch='1';new MutationObserver(function(){addWhatsApp();}).observe(req,{childList:true,subtree:true});}"
            + "}catch(e){console.log('SerraAzul Android UI',e);}})();";
        view.evaluateJavascript(js, null);
    }

    /** Ponte nativa usada somente pelo APK para abrir o compartilhamento do WhatsApp. */
    private class WhatsAppBridge {
        @JavascriptInterface
        public void sendWhatsApp(String message) {
            runOnUiThread(() -> {
                try {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_TEXT, message == null ? "" : message);
                    Intent chooser = Intent.createChooser(send, "Enviar solicitação pelo WhatsApp");
                    startActivity(chooser);
                } catch (Exception ignored) {
                    try {
                        Uri uri = Uri.parse("https://wa.me/?text=" + Uri.encode(message == null ? "" : message));
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (Exception ignored2) {}
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }
}
