# Serra Azul BF — Android APK

Este projeto transforma o site online Serra Azul BF em um aplicativo Android usando WebView.

URL carregada: https://ngcyuri.github.io/serra-azul-bf/

A interface e os dados continuam no site/Supabase; o APK é o contêiner Android.

## Gerar o APK no Android Studio
1. Abra esta pasta no Android Studio.
2. Aguarde o Gradle sincronizar.
3. Se solicitado, instale Android SDK Platform 35 e Build Tools.
4. Menu Build > Build APK(s).
5. O APK de debug ficará em `app/build/outputs/apk/debug/app-debug.apk`.

Para distribuição, use Build > Generate Signed Bundle / APK e gere um APK assinado.
