package br.com.serraazulbf;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewFeature;

public class MainActivity extends AppCompatActivity {
    private static final String APP_URL = "https://ngcyuri.github.io/serra-azul-bf/";
    private WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setUseWideViewPort(false);
        s.setLoadWithOverviewMode(false);
        s.setTextZoom(100);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setUserAgentString(s.getUserAgentString() + " SerraAzulBF-Android/1.2");

        if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            WebSettingsCompat.setForceDark(s, WebSettingsCompat.FORCE_DARK_OFF);
        }

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost();
                if (host != null && (host.equals("ngcyuri.github.io") || host.endsWith("supabase.co") || host.endsWith("supabase.com"))) {
                    return false;
                }
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
                return true;
            }

            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                injectMobileOnlyStyles(view);
            }
        });

        webView.loadUrl(APP_URL);

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack(); else finish();
            }
        });
    }

    private void injectMobileOnlyStyles(WebView view) {
        String css = ""
            + "html,body{max-width:100%!important;overflow-x:hidden!important;}"
            + "#app-shell{max-width:100%!important;overflow-x:hidden!important;}"
            + "@media(max-width:760px){"
            + "  html,body{width:100%!important;min-width:0!important;}"
            + "  #app-shell{width:100%!important;min-width:0!important;}"
            + "  .modal-overlay{padding:10px!important;overflow-x:hidden!important;overflow-y:auto!important;align-items:flex-start!important;}"
            + "  .modal-panel{width:100%!important;max-width:none!important;min-width:0!important;box-sizing:border-box!important;padding:14px!important;overflow-x:hidden!important;}"
            + "  /* Consertos e Solicitações: no celular as tabelas viram cards. */"
            + "  #repairs-modal .responsive-table,#requests-modal .responsive-table{width:100%!important;max-width:100%!important;min-width:0!important;overflow-x:hidden!important;overflow-y:visible!important;max-height:none!important;border:0!important;border-radius:0!important;}"
            + "  #repairs-modal .responsive-table>table,#requests-modal .responsive-table>table{display:block!important;width:100%!important;min-width:0!important;max-width:100%!important;border:0!important;table-layout:fixed!important;}"
            + "  #repairs-modal .responsive-table>table>thead,#requests-modal .responsive-table>table>thead{display:none!important;}"
            + "  #repairs-modal .responsive-table>table>tbody,#requests-modal .responsive-table>table>tbody{display:block!important;width:100%!important;}"
            + "  #repairs-modal .responsive-table>table>tbody>tr,#requests-modal .responsive-table>table>tbody>tr{display:block!important;width:100%!important;box-sizing:border-box!important;margin:0 0 12px!important;padding:12px!important;border:1px solid #e2e8f0!important;border-radius:14px!important;background:#fff!important;box-shadow:0 3px 12px rgba(15,23,42,.05)!important;}"
            + "  #repairs-modal .responsive-table>table>tbody>tr:last-child,#requests-modal .responsive-table>table>tbody>tr:last-child{margin-bottom:0!important;}"
            + "  #repairs-modal .responsive-table>table>tbody>tr>td,#requests-modal .responsive-table>table>tbody>tr>td{display:grid!important;grid-template-columns:minmax(105px,34%) minmax(0,1fr)!important;gap:8px!important;width:100%!important;box-sizing:border-box!important;padding:6px 0!important;border:0!important;text-align:left!important;white-space:normal!important;overflow-wrap:anywhere!important;}"
            + "  #repairs-modal .responsive-table>table>tbody>tr>td:before,#requests-modal .responsive-table>table>tbody>tr>td:before{font-size:10px!important;line-height:1.25!important;font-weight:800!important;text-transform:uppercase!important;letter-spacing:.05em!important;color:#64748b!important;align-self:start!important;}"
            + "  #requests-modal .responsive-table>table>tbody>tr>td:nth-child(1):before{content:'Data';}"
            + "  #requests-modal .responsive-table>table>tbody>tr>td:nth-child(2):before{content:'Produto / Material';}"
            + "  #requests-modal .responsive-table>table>tbody>tr>td:nth-child(3):before{content:'Código Protheus';}"
            + "  #requests-modal .responsive-table>table>tbody>tr>td:nth-child(4):before{content:'Quantidade';}"
            + "  #requests-modal .responsive-table>table>tbody>tr>td:nth-child(5):before{content:'Solicitante';}"
            + "  #requests-modal .responsive-table>table>tbody>tr>td:nth-child(6):before{content:'Status';}"
            + "  #requests-modal .responsive-table>table>tbody>tr>td:nth-child(7):before{content:'Ações';}"
            + "  #repairs-modal .responsive-table>table>tbody>tr>td:nth-child(1):before{content:'Envio';}"
            + "  #repairs-modal .responsive-table>table>tbody>tr>td:nth-child(2):before{content:'Mercadoria';}"
            + "  #repairs-modal .responsive-table>table>tbody>tr>td:nth-child(3):before{content:'Fornecedor';}"
            + "  #repairs-modal .responsive-table>table>tbody>tr>td:nth-child(4):before{content:'NF saída';}"
            + "  #repairs-modal .responsive-table>table>tbody>tr>td:nth-child(5):before{content:'Responsável';}"
            + "  #repairs-modal .responsive-table>table>tbody>tr>td:nth-child(6):before{content:'Status';}"
            + "  #repairs-modal .responsive-table>table>tbody>tr>td:nth-child(7):before{content:'NF retorno';}"
            + "  #repairs-modal .responsive-table>table>tbody>tr>td:nth-child(8):before{content:'Retorno';}"
            + "  #repairs-modal .responsive-table>table>tbody>tr>td:nth-child(9):before{content:'Dias fora';}"
            + "  #repairs-modal .responsive-table>table>tbody>tr>td:nth-child(10):before{content:'Ações';}"
            + "  #repairs-modal .responsive-table>table>tbody>tr>td:last-child,#requests-modal .responsive-table>table>tbody>tr>td:last-child{display:flex!important;justify-content:flex-end!important;align-items:center!important;gap:8px!important;padding-top:10px!important;margin-top:4px!important;border-top:1px solid #f1f5f9!important;}"
            + "  #repairs-modal .responsive-table button,#requests-modal .responsive-table button{min-width:38px!important;min-height:38px!important;padding:8px!important;border-radius:9px!important;}"
            + "  #repairs-modal .responsive-table .repair-status-badge,#requests-modal .responsive-table .repair-status-badge{display:inline-flex!important;align-items:center!important;justify-content:center!important;max-width:100%!important;white-space:normal!important;text-align:center!important;}"
            + "  /* filtros ficam empilhados e fáceis de tocar */"
            + "  #repairs-modal .mb-4.grid,#requests-modal .mb-4.flex{display:flex!important;flex-direction:column!important;align-items:stretch!important;width:100%!important;}"
            + "  #repairs-modal .mb-4.grid>*,#requests-modal .mb-4.flex>*{width:100%!important;min-width:0!important;box-sizing:border-box!important;}"
            + "  #repairs-modal .mb-4.grid button,#requests-modal .mb-4.flex button{min-height:44px!important;justify-content:center!important;}"
            + "  #repairs-modal .mb-5.grid,#requests-modal .mb-5.grid{grid-template-columns:repeat(2,minmax(0,1fr))!important;}"
            + "  #repairs-modal h2,#requests-modal h2{font-size:18px!important;line-height:1.25!important;}"
            + "  #repairs-modal p,#requests-modal p{line-height:1.4!important;}"
            + "  #requests-modal .responsive-table>table>tbody>tr>td:nth-child(2),#repairs-modal .responsive-table>table>tbody>tr>td:nth-child(2){font-weight:600!important;color:#0f172a!important;}"
            + "}"
            + "@media(max-width:390px){"
            + "  .modal-overlay{padding:6px!important;}"
            + "  .modal-panel{padding:12px!important;}"
            + "  #repairs-modal .mb-5.grid,#requests-modal .mb-5.grid{gap:8px!important;}"
            + "  #repairs-modal .mb-5.grid>div,#requests-modal .mb-5.grid>div{padding:10px!important;}"
            + "  #repairs-modal .responsive-table>table>tbody>tr>td,#requests-modal .responsive-table>table>tbody>tr>td{grid-template-columns:40% minmax(0,60%)!important;gap:6px!important;}"
            + "}";

        String safeCss = css.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
        String js = "javascript:(function(){"
            + "var m=document.querySelector('meta[name=viewport]');"
            + "if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m);}"
            + "m.setAttribute('content','width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover');"
            + "var s=document.getElementById('serra-azul-android-mobile-css');"
            + "if(!s){s=document.createElement('style');s.id='serra-azul-android-mobile-css';document.head.appendChild(s);}"
            + "s.textContent='" + safeCss + "';"
            + "document.documentElement.style.maxWidth='100%';"
            + "document.documentElement.style.overflowX='hidden';"
            + "document.body.style.maxWidth='100%';"
            + "document.body.style.overflowX='hidden';"
            + "})();";
        view.evaluateJavascript(js, null);
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.stopLoading(); webView.destroy(); }
        super.onDestroy();
    }
}
