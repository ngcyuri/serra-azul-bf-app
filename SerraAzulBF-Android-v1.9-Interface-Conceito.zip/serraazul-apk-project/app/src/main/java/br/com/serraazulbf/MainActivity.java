package br.com.serraazulbf;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewFeature;

public class MainActivity extends AppCompatActivity {
    private static final String APP_URL = "https://ngcyuri.github.io/serra-azul-bf/";
    private WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(false);
        s.setTextZoom(100);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setUserAgentString(s.getUserAgentString() + " SerraAzulBF-Android/1.9");

        if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            WebSettingsCompat.setForceDark(s, WebSettingsCompat.FORCE_DARK_OFF);
        }

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new WhatsAppBridge(), "SerraAzulAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost();
                if (host != null && (host.equals("ngcyuri.github.io") || host.endsWith("supabase.co") || host.endsWith("supabase.com"))) {
                    return false;
                }
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                injectAppOnlyMobileStyle(view);
            }
        });

        webView.loadUrl(APP_URL);

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack(); else finish();
            }
        });
    }

    /**
     * Ajustes exclusivos do APK. O site publicado no GitHub Pages não é alterado.
     * A tabela de Consertos e Solicitações vira cartão no celular, eliminando
     * a rolagem horizontal e os cabeçalhos cortados.
     */
    private void injectAppOnlyMobileStyle(WebView view) {
        String css = ""
            + "@media (max-width:760px){"
            + "*{box-sizing:border-box!important;}"
            + "html,body{width:100%!important;max-width:100%!important;overflow-x:hidden!important;background:#f5f9fb!important;}"
            + "body{font-family:Arial,sans-serif!important;color:#18324b!important;}"
            + "#fullscreen-btn{display:none!important;}"
            + "#app-shell{background:#f5f9fb!important;min-height:100vh!important;}"
            + "header.canva-header{background:#fff!important;color:#18324b!important;border-bottom:1px solid #e2eaf0!important;box-shadow:0 1px 5px rgba(15,23,42,.04)!important;padding:10px 14px!important;}"
            + "header.canva-header>.mx-auto{display:flex!important;align-items:center!important;gap:8px!important;max-width:none!important;}"
            + "header.canva-header .brand-title{display:flex!important;align-items:center!important;gap:8px!important;min-width:0!important;flex:1 1 auto!important;}"
            + "header.canva-header .brand-logo{width:82px!important;max-width:82px!important;height:auto!important;max-height:45px!important;object-fit:contain!important;flex:0 0 auto!important;}"
            + "header.canva-header [data-template-id='page-title']{font-size:17px!important;line-height:1.05!important;letter-spacing:-.02em!important;color:#18324b!important;word-break:normal!important;overflow-wrap:normal!important;margin:0!important;}"
            + "header.canva-header [data-template-id='page-subtitle']{display:none!important;}"
            + "#user-area{display:flex!important;align-items:center!important;gap:5px!important;}"
            + "#user-badge{max-width:154px!important;padding:6px 8px!important;border:1px solid #dce7ef!important;background:#fff!important;color:#18324b!important;box-shadow:none!important;border-radius:18px!important;}"
            + "#user-email{font-size:10px!important;max-width:105px!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important;}"
            + "#user-role{display:none!important;}"
            + "#logout-btn{padding:7px 9px!important;font-size:11px!important;border:1px solid #dce7ef!important;background:#fff!important;color:#18324b!important;border-radius:10px!important;}"
            + "main.mx-auto.max-w-7xl{max-width:none!important;padding:12px 14px 70px!important;background:#f5f9fb!important;}"
            + "#tabs-container{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:8px!important;margin:0!important;}"
            + "#tabs-container::before{content:'MÊS E MÓDULOS';grid-column:1/-1;font-size:11px;font-weight:800;color:#5c7690;letter-spacing:.08em;margin:2px 2px 1px;}"
            + "#tabs-container>button{width:100%!important;min-width:0!important;min-height:48px!important;justify-content:center!important;padding:9px 7px!important;border-radius:12px!important;border:1px solid #dce7ef!important;background:#fff!important;color:#19364f!important;box-shadow:0 1px 5px rgba(15,23,42,.035)!important;font-size:12px!important;font-weight:700!important;}"
            + "#tabs-container>button[data-month]{min-height:52px!important;font-size:12px!important;font-weight:800!important;color:#59728a!important;}"
            + "#tabs-container>button[data-month].tab-active{background:#1d466c!important;color:#fff!important;border-color:#1d466c!important;box-shadow:0 4px 10px rgba(29,70,108,.18)!important;}"
            + "#tabs-container>button:nth-child(1),#tabs-container>button:nth-child(2){min-height:54px!important;}"
            + "#tabs-container>button:nth-last-child(1){grid-column:1!important;}"
            + "#summary-cards{display:none!important;margin:16px 0 12px!important;gap:8px!important;}"
            + "#summary-cards.android-month-open{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;}"
            + "#summary-cards::before{content:'INDICADORES DO MÊS';grid-column:1/-1;font-size:11px;font-weight:800;color:#5c7690;letter-spacing:.08em;margin:0 2px 1px;}"
            + "#summary-cards .card-stat{padding:12px!important;border:1px solid #dce7ef!important;border-radius:12px!important;background:#fff!important;box-shadow:0 1px 5px rgba(15,23,42,.035)!important;}"
            + "#summary-cards .card-stat p:first-child{font-size:8px!important;letter-spacing:.08em!important;color:#6d8498!important;}"
            + "#summary-cards .card-stat p:last-child{font-size:22px!important;margin-top:2px!important;color:#102b45!important;}"
            + "main>.filter-grid{display:none!important;margin-top:10px!important;grid-template-columns:1fr!important;gap:7px!important;}"
            + "main>.filter-grid.android-orders-visible{display:grid!important;}"
            + "main>.filter-grid>div{min-width:0!important;width:100%!important;}"
            + "main>.filter-grid input,main>.filter-grid select{min-height:42px!important;font-size:14px!important;border-radius:10px!important;}"
            + "main>section[aria-label='Pedidos de compra']{display:none!important;}"
            + "main>section[aria-label='Pedidos de compra'].android-orders-visible{display:block!important;margin-top:10px!important;}"
            + "#orders-toggle-wrap{display:none!important;}"
            + "#orders-table{min-width:0!important;width:100%!important;border-collapse:separate!important;border-spacing:0!important;}"
            + "#orders-table thead{display:none!important;}"
            + "#orders-body{display:block!important;width:100%!important;}"
            + "#orders-body tr{display:block!important;width:100%!important;margin:0 0 8px!important;padding:11px!important;border:1px solid #dce7ef!important;border-radius:13px!important;background:#fff!important;box-shadow:0 1px 6px rgba(15,23,42,.035)!important;}"
            + "#orders-body td{display:flex!important;justify-content:space-between!important;gap:8px!important;width:100%!important;padding:5px 0!important;border:0!important;text-align:right!important;font-size:11px!important;white-space:normal!important;word-break:break-word!important;line-height:1.25!important;}"
            + "#orders-body td:before{flex:0 0 40%!important;text-align:left!important;color:#6b8398!important;font-size:8px!important;font-weight:800!important;text-transform:uppercase!important;letter-spacing:.04em!important;}"
            + "#orders-body td:nth-child(1):before{content:'Fornecedor'}#orders-body td:nth-child(2):before{content:'Orçamento'}#orders-body td:nth-child(3):before{content:'Recebimento'}#orders-body td:nth-child(4):before{content:'Pedido'}#orders-body td:nth-child(5):before{content:'Dia feito'}#orders-body td:nth-child(6):before{content:'Status'}"
            + ".modal-overlay{padding:0!important;align-items:stretch!important;justify-content:stretch!important;background:rgba(15,35,52,.25)!important;backdrop-filter:blur(4px)!important;}"
            + ".modal-overlay .modal-panel{width:100%!important;max-width:none!important;height:100dvh!important;max-height:100dvh!important;margin:0!important;border-radius:0!important;padding:12px 14px 72px!important;overflow:auto!important;box-shadow:none!important;background:#f5f9fb!important;}"
            + ".modal-overlay .modal-panel>div:first-child{position:sticky!important;top:-12px!important;z-index:20!important;margin:-12px -14px 12px!important;padding:12px 14px!important;background:rgba(255,255,255,.98)!important;border-bottom:1px solid #e0e8ef!important;}"
            + ".modal-overlay .modal-panel h2{font-size:18px!important;color:#173650!important;}"
            + ".modal-overlay .modal-panel h3{font-size:14px!important;color:#25435d!important;}"
            + "#dashboard-modal .modal-panel,#reports-modal .modal-panel,#requests-modal .modal-panel,#repairs-modal .modal-panel,#users-modal .modal-panel,#suppliers-modal .modal-panel,#history-modal .modal-panel{background:#f5f9fb!important;}"
            + "#dashboard-modal .modal-panel .grid{gap:8px!important;}"
            + "#dashboard-modal .modal-panel .card-stat{border-radius:12px!important;border:1px solid #dce7ef!important;background:#fff!important;box-shadow:0 1px 6px rgba(15,23,42,.035)!important;}"
            + "#dashboard-modal .modal-panel .grid>div:first-child{background:#1d466c!important;color:#fff!important;border-color:#1d466c!important;}"
            + "#requests-modal .mb-5.grid,#repairs-modal .mb-5.grid{grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:7px!important;}"
            + "#requests-modal .mb-4.flex,#repairs-modal .mb-4.grid{grid-template-columns:1fr!important;gap:7px!important;}"
            + "#requests-modal .mb-4.flex>* ,#repairs-modal .mb-4.grid>*{width:100%!important;min-width:0!important;}"
            + "#requests-modal input,#repairs-modal input,#requests-modal select,#repairs-modal select{min-height:42px!important;border-radius:10px!important;font-size:14px!important;}"
            + "#requests-modal table,#repairs-modal table,#history-modal table,#suppliers-modal table,#users-modal table{width:100%!important;min-width:0!important;border-collapse:separate!important;border-spacing:0!important;}"
            + "#requests-modal thead,#repairs-modal thead,#history-modal thead,#suppliers-modal thead,#users-modal thead{display:none!important;}"
            + "#requests-modal #requests-body,#repairs-modal #repairs-body,#history-modal #history-body{display:block!important;width:100%!important;}"
            + "#requests-modal #requests-body tr,#repairs-modal #repairs-body tr,#history-modal #history-body tr,#suppliers-modal tbody tr,#users-modal tbody tr{display:block!important;width:100%!important;margin:0 0 8px!important;padding:12px!important;border:1px solid #dce7ef!important;border-radius:13px!important;background:#fff!important;box-shadow:0 1px 6px rgba(15,23,42,.035)!important;}"
            + "#requests-modal #requests-body td,#repairs-modal #repairs-body td,#history-modal #history-body td,#suppliers-modal tbody td,#users-modal tbody td{display:flex!important;align-items:flex-start!important;justify-content:space-between!important;gap:8px!important;width:100%!important;padding:5px 0!important;border:0!important;text-align:right!important;font-size:11px!important;line-height:1.3!important;white-space:normal!important;word-break:break-word!important;}"
            + "#requests-modal #requests-body td:before,#repairs-modal #repairs-body td:before,#history-modal #history-body td:before,#suppliers-modal tbody td:before,#users-modal tbody td:before{flex:0 0 38%!important;text-align:left!important;color:#6b8398!important;font-size:8px!important;font-weight:800!important;text-transform:uppercase!important;letter-spacing:.04em!important;}"
            + "#requests-modal #requests-body td:nth-child(1):before{content:'Data'}#requests-modal #requests-body td:nth-child(2):before{content:'Produto'}#requests-modal #requests-body td:nth-child(3):before{content:'Código Protheus'}#requests-modal #requests-body td:nth-child(4):before{content:'Quantidade'}#requests-modal #requests-body td:nth-child(5):before{content:'Solicitante'}#requests-modal #requests-body td:nth-child(6):before{content:'Status'}"
            + "#repairs-modal #repairs-body td:nth-child(1):before{content:'Envio'}#repairs-modal #repairs-body td:nth-child(2):before{content:'Mercadoria'}#repairs-modal #repairs-body td:nth-child(3):before{content:'Fornecedor'}#repairs-modal #repairs-body td:nth-child(4):before{content:'NF saída'}#repairs-modal #repairs-body td:nth-child(5):before{content:'Responsável'}#repairs-modal #repairs-body td:nth-child(6):before{content:'Status'}#repairs-modal #repairs-body td:nth-child(7):before{content:'NF retorno'}#repairs-modal #repairs-body td:nth-child(8):before{content:'Retorno'}#repairs-modal #repairs-body td:nth-child(9):before{content:'Dias fora'}"
            + "#history-modal #history-body td:nth-child(1):before{content:'Data/Hora'}#history-modal #history-body td:nth-child(2):before{content:'Usuário'}#history-modal #history-body td:nth-child(3):before{content:'Ação'}#history-modal #history-body td:nth-child(4):before{content:'Registro'}#history-modal #history-body td:nth-child(5):before{content:'Descrição'}"
            + "#requests-modal #requests-body td:last-child,#repairs-modal #repairs-body td:last-child{justify-content:flex-end!important;margin-top:4px!important;padding-top:8px!important;border-top:1px solid #edf2f6!important;}"
            + "#requests-modal #requests-body td:last-child:before,#repairs-modal #repairs-body td:last-child:before{display:none!important;}"
            + "#request-form-modal input,#request-form-modal select,#request-form-modal textarea,#repair-form-modal input,#repair-form-modal select,#repair-form-modal textarea{min-height:44px!important;font-size:16px!important;max-width:100%!important;border-radius:10px!important;}"
            + "#request-form-modal textarea,#repair-form-modal textarea{min-height:88px!important;}"
            + ".android-wa-btn{min-height:38px!important;padding:7px 10px!important;border:1px solid #22c55e!important;border-radius:10px!important;background:#ecfdf5!important;color:#15803d!important;font-weight:800!important;font-size:11px!important;box-shadow:none!important;}"
            + "#sync-status{position:fixed!important;left:12px!important;right:12px!important;bottom:10px!important;z-index:9999!important;border-radius:16px!important;background:rgba(255,255,255,.97)!important;border:1px solid #dbe5ee!important;box-shadow:0 5px 20px rgba(15,23,42,.10)!important;padding:7px 9px!important;font-size:9px!important;}"
            + "#sync-status-message{font-size:9px!important;}#realtime-status{font-size:9px!important;}"
            + "body.android-module-open #tabs-container{display:none!important;}"
            + "body.android-module-open #summary-cards{display:none!important;}"
            + "body.android-module-open main>.filter-grid{display:none!important;}"
            + "body.android-module-open main>section[aria-label='Pedidos de compra']{display:none!important;}"
            + "body.android-module-open .modal-overlay{display:flex!important;}"
            + "}"
            + "@media (min-width:761px){.serra-azul-bf-android{}}";

        String encoded = Base64.encodeToString(css.getBytes(java.nio.charset.StandardCharsets.UTF_8), Base64.NO_WRAP);
        String js = "(function(){try{"
            + "var id='serra-azul-bf-android-ui';var old=document.getElementById(id);if(old)old.remove();"
            + "var s=document.createElement('style');s.id=id;s.textContent=decodeURIComponent(escape(atob('" + encoded + "')));document.head.appendChild(s);"
            + "document.documentElement.classList.add('serra-azul-bf-android');"
            + "var title=document.querySelector(\"header.canva-header [data-template-id='page-title']\");if(title)title.textContent='Serra Azul BF';"
            + "var summary=document.getElementById('summary-cards');"
            + "var orderFilters=document.querySelector('main>.filter-grid');"
            + "var orderSection=document.querySelector(\"main>section[aria-label='Pedidos de compra']\");"
            + "function bindMonthButtons(){document.querySelectorAll('#tabs-container button[data-month]').forEach(function(b){if(b.dataset.androidMonth==='1')return;b.dataset.androidMonth='1';b.addEventListener('click',function(){setTimeout(function(){document.body.classList.remove('android-module-open');if(summary)summary.classList.add('android-month-open');if(orderFilters)orderFilters.classList.add('android-orders-visible');if(orderSection)orderSection.classList.add('android-orders-visible');},100);});});}"
            + "if(summary)summary.classList.remove('android-month-open');bindMonthButtons();"
            + "var tabs=document.getElementById('tabs-container');if(tabs&&!tabs.dataset.androidWatch){tabs.dataset.androidWatch='1';new MutationObserver(function(){bindMonthButtons();}).observe(tabs,{childList:true,subtree:true});}"
            + "function openModuleAfter(fn){return function(){document.body.classList.add('android-module-open');return fn.apply(this,arguments);};}"
            + "['openDashboardModal','openReportsModal','openUsersModal','openHistoryModal','openSuppliersModal','openRepairsModal','openRequestsModal'].forEach(function(name){if(typeof window[name]==='function'&&window[name].__androidWrapped!==true){var original=window[name];var wrapped=function(){document.body.classList.add('android-module-open');return original.apply(this,arguments);};wrapped.__androidWrapped=true;window[name]=wrapped;}});"
            + "function addWhatsApp(){var body=document.querySelector('#requests-modal #requests-body');if(!body)return;body.querySelectorAll('tr').forEach(function(tr){var td=tr.querySelectorAll('td');if(td.length<7)return;var status=(td[5].innerText||'').trim();if(!/^(Em andamento|Atendida|Finalizada)$/i.test(status))return;var action=td[6];if(!action||action.querySelector('.android-wa-btn'))return;var val=function(i){return td[i]?(td[i].innerText||'').trim():''};var msg='📦 SOLICITAÇÃO DE REPOSIÇÃO\\n\\nProduto/Material: '+val(1)+'\\nCódigo Protheus: '+val(2)+'\\nQuantidade: '+val(3)+'\\nSolicitante: '+val(4)+'\\nData: '+val(0)+'\\n\\n⚠️ ESTOQUE BAIXO\\nO produto/material está acabando. Favor solicitar a reposição no TOTVS.';var b=document.createElement('button');b.className='android-wa-btn';b.type='button';b.textContent='WhatsApp';b.onclick=function(e){e.preventDefault();e.stopPropagation();if(window.SerraAzulAndroid){window.SerraAzulAndroid.sendWhatsApp(msg);}else{window.open('https://wa.me/?text='+encodeURIComponent(msg),'_blank');}};action.appendChild(b);});}"
            + "addWhatsApp();var req=document.getElementById('requests-modal');if(req&&!req.dataset.androidWatch){req.dataset.androidWatch='1';new MutationObserver(function(){addWhatsApp();}).observe(req,{childList:true,subtree:true});}"
            + "}catch(e){console.log('SerraAzul Android UI',e);}})();";
        view.evaluateJavascript(js, null);
    }

    /** Ponte nativa usada somente pelo APK para abrir o compartilhamento do WhatsApp. */
    private class WhatsAppBridge {
        @JavascriptInterface
        public void sendWhatsApp(String message) {
            runOnUiThread(() -> {
                try {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_TEXT, message == null ? "" : message);
                    Intent chooser = Intent.createChooser(send, "Enviar solicitação pelo WhatsApp");
                    startActivity(chooser);
                } catch (Exception ignored) {
                    try {
                        Uri uri = Uri.parse("https://wa.me/?text=" + Uri.encode(message == null ? "" : message));
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (Exception ignored2) {}
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }
}
