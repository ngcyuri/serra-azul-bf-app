package br.com.serraazulbf;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import java.nio.charset.StandardCharsets;
import android.util.Base64;

public class MainActivity extends AppCompatActivity {
    private static final String APP_URL = "https://ngcyuri.github.io/serra-azul-bf/";
    private WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setUseWideViewPort(false);
        s.setLoadWithOverviewMode(false);
        s.setTextZoom(100);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setUserAgentString(s.getUserAgentString() + " SerraAzulBF-Android/2.0");

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new WhatsAppBridge(), "SerraAzulAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost();
                if (host != null && (host.equals("ngcyuri.github.io") || host.endsWith("supabase.co") || host.endsWith("supabase.com"))) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) { }
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.postDelayed(() -> injectAppMobileUI(view), 180);
                view.postDelayed(() -> injectAppMobileUI(view), 900);
            }
        });

        webView.loadUrl(APP_URL);

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                webView.evaluateJavascript("(function(){var ids=['modal','month-modal','edit-month-modal','suppliers-modal','users-modal','requests-modal','request-form-modal','repairs-modal','repair-detail-modal','repair-form-modal','history-modal','history-detail-modal','dashboard-modal','reports-modal'];for(var i=0;i<ids.length;i++){var e=document.getElementById(ids[i]);if(e&&!e.classList.contains('hidden')){var b=e.querySelector('button[onclick*=\\\"close\\\"]');if(b){b.click();return 'closed';}}}return 'none';})()", value -> {
                    if (value == null || value.contains("none")) {
                        if (webView.canGoBack()) webView.goBack(); else finish();
                    }
                });
            }
        });
    }

    /**
     * Interface mobile exclusiva do APK. O site publicado permanece inalterado.
     * A abordagem usa somente CSS + listeners delegados, sem substituir funções
     * do site, reduzindo risco de crash e preservando Supabase, login e realtime.
     */
    private void injectAppMobileUI(WebView view) {
        String css = ""
            + "@media (max-width:760px){"
            + "html,body{width:100%!important;max-width:100%!important;overflow-x:hidden!important;background:#f4f8fb!important;}"
            + "body{margin:0!important;font-family:Arial,sans-serif!important;color:#18324b!important;}"
            + "*,*:before,*:after{box-sizing:border-box!important;}"
            + "#fullscreen-btn{display:none!important;}"
            + "header.canva-header{padding:9px 14px 11px!important;background:#fff!important;border-bottom:1px solid #e1e9ef!important;box-shadow:0 1px 7px rgba(15,23,42,.05)!important;}"
            + "header.canva-header>.mx-auto{max-width:none!important;display:flex!important;align-items:center!important;gap:9px!important;}"
            + "header.canva-header .brand-logo{width:76px!important;max-width:76px!important;height:auto!important;max-height:42px!important;object-fit:contain!important;}"
            + "header.canva-header .brand-title{min-width:0!important;flex:1 1 auto!important;}"
            + "header.canva-header [data-template-id='page-title']{font-size:16px!important;line-height:1.08!important;letter-spacing:-.02em!important;color:#17334c!important;white-space:normal!important;word-break:normal!important;overflow-wrap:normal!important;margin:0!important;}"
            + "header.canva-header [data-template-id='page-subtitle']{display:none!important;}"
            + "#user-area{gap:6px!important;flex:0 0 auto!important;}"
            + "#user-badge{max-width:145px!important;padding:6px 8px!important;border:1px solid #dce6ee!important;border-radius:18px!important;background:#fff!important;box-shadow:none!important;}"
            + "#user-email{font-size:9px!important;max-width:94px!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important;}"
            + "#user-role{display:none!important;}"
            + "#logout-btn{padding:7px 9px!important;border:1px solid #dce6ee!important;background:#fff!important;color:#18324b!important;border-radius:10px!important;font-size:10px!important;}"
            + "main.mx-auto.max-w-7xl{max-width:none!important;width:100%!important;padding:13px 14px 88px!important;background:#f4f8fb!important;}"
            + "#tabs-container{width:100%!important;display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:8px!important;border:0!important;margin:0 0 13px!important;padding:0!important;overflow:visible!important;}"
            + "#tabs-container:before{content:'MÊS E MÓDULOS';grid-column:1/-1;font-size:11px!important;font-weight:800!important;letter-spacing:.10em!important;color:#5e7488!important;padding:1px 2px 0!important;}"
            + "#tabs-container>button{width:100%!important;min-width:0!important;min-height:48px!important;margin:0!important;padding:9px 6px!important;border-radius:11px!important;border:1px solid #dce6ee!important;background:#fff!important;color:#183a57!important;box-shadow:0 1px 5px rgba(15,23,42,.035)!important;font-size:12px!important;font-weight:750!important;justify-content:center!important;}"
            + "#tabs-container>button:nth-child(1),#tabs-container>button:nth-child(2){grid-column:1/-1!important;min-height:51px!important;font-size:13px!important;}"
            + "#tabs-container>button[data-month]{min-height:52px!important;}"
            + "#tabs-container>button.tab-active{background:#1e4b73!important;border-color:#1e4b73!important;color:#fff!important;box-shadow:0 5px 13px rgba(30,75,115,.18)!important;}"
            + "#tabs-container>button[data-month].tab-inactive{background:#fff!important;color:#5d7389!important;}"
            + "#tabs-container>button i{width:16px!important;height:16px!important;}"
            + "#summary-cards{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:8px!important;margin:0 0 12px!important;}"
            + "#summary-cards:before{content:'INDICADORES DO MÊS';grid-column:1/-1;font-size:11px!important;font-weight:800!important;letter-spacing:.10em!important;color:#5e7488!important;padding:1px 2px 0!important;}"
            + "#summary-cards .card-stat{min-width:0!important;padding:12px!important;border:1px solid #dce6ee!important;border-radius:12px!important;background:#fff!important;box-shadow:0 1px 5px rgba(15,23,42,.035)!important;}"
            + "#summary-cards .card-stat p:first-child{font-size:8px!important;letter-spacing:.08em!important;color:#71869a!important;margin:0!important;}"
            + "#summary-cards .card-stat p:last-child{font-size:22px!important;line-height:1.1!important;margin:4px 0 0!important;color:#102b45!important;}"
            + "main>.filter-grid{display:grid!important;grid-template-columns:1fr!important;gap:7px!important;margin:0 0 10px!important;}"
            + "main>.filter-grid>div{min-width:0!important;width:100%!important;}"
            + "main>.filter-grid input,main>.filter-grid select{width:100%!important;min-height:42px!important;border-radius:10px!important;font-size:14px!important;}"
            + "main>.filter-grid button{min-height:42px!important;border-radius:10px!important;}"
            + "main>section[aria-label='Pedidos de compra']{width:100%!important;overflow:hidden!important;border-radius:13px!important;background:#fff!important;}"
            + "#orders-table{width:100%!important;min-width:0!important;border-collapse:separate!important;border-spacing:0!important;}"
            + "#orders-table thead{display:none!important;}"
            + "#orders-body{display:block!important;width:100%!important;}"
            + "#orders-body tr{display:block!important;width:100%!important;margin:0 0 8px!important;padding:11px!important;border:1px solid #dce6ee!important;border-radius:13px!important;background:#fff!important;box-shadow:0 1px 5px rgba(15,23,42,.035)!important;}"
            + "#orders-body td{display:flex!important;align-items:flex-start!important;justify-content:space-between!important;gap:9px!important;width:100%!important;padding:5px 0!important;border:0!important;text-align:right!important;font-size:11px!important;line-height:1.28!important;white-space:normal!important;word-break:break-word!important;}"
            + "#orders-body td:before{flex:0 0 39%!important;text-align:left!important;color:#71869a!important;font-size:8px!important;font-weight:800!important;text-transform:uppercase!important;letter-spacing:.04em!important;}"
            + "#orders-body td:nth-child(1):before{content:'Fornecedor'}#orders-body td:nth-child(2):before{content:'Orçamento'}#orders-body td:nth-child(3):before{content:'Recebido'}#orders-body td:nth-child(4):before{content:'Pedido de compra'}#orders-body td:nth-child(5):before{content:'Dia feito'}#orders-body td:nth-child(6):before{content:'Status'}"
            + ".responsive-table{max-width:100%!important;}"
            + "#sync-status{position:fixed!important;left:10px!important;right:10px!important;bottom:9px!important;z-index:9000!important;padding:7px 8px!important;border:1px solid #dce6ee!important;border-radius:17px!important;background:rgba(255,255,255,.97)!important;box-shadow:0 7px 22px rgba(15,23,42,.12)!important;font-size:9px!important;}"
            + "#sync-status-message,#realtime-status{font-size:9px!important;}"
            + ".modal-overlay:not(.hidden){position:fixed!important;inset:0!important;z-index:8000!important;display:flex!important;align-items:stretch!important;justify-content:stretch!important;padding:0!important;background:rgba(244,248,251,.98)!important;backdrop-filter:blur(5px)!important;}"
            + ".modal-overlay:not(.hidden)>.modal-panel{width:100%!important;max-width:none!important;height:100%!important;max-height:none!important;margin:0!important;border-radius:0!important;padding:14px!important;overflow:auto!important;box-shadow:none!important;background:#f4f8fb!important;}"
            + ".modal-overlay:not(.hidden)>.modal-panel>div:first-child{position:sticky!important;top:0!important;z-index:2!important;margin:-14px -14px 12px!important;padding:13px 14px!important;background:rgba(244,248,251,.97)!important;border-bottom:1px solid #e0e8ef!important;}"
            + "#dashboard-modal .modal-panel,#reports-modal .modal-panel,#requests-modal .modal-panel,#repairs-modal .modal-panel,#suppliers-modal .modal-panel,#users-modal .modal-panel,#history-modal .modal-panel{background:#f4f8fb!important;}"
            + "#requests-modal table,#repairs-modal table,#history-modal table,#suppliers-modal table,#users-modal table{width:100%!important;min-width:0!important;border-collapse:separate!important;border-spacing:0!important;}"
            + "#requests-modal .responsive-table,#repairs-modal .responsive-table,#history-modal .responsive-table,#suppliers-modal .responsive-table,#users-modal .responsive-table{max-height:none!important;overflow:visible!important;border:0!important;border-radius:0!important;}"
            + "#requests-modal thead,#repairs-modal thead,#history-modal thead,#suppliers-modal thead,#users-modal thead{display:none!important;}"
            + "#requests-body,#repairs-body,#history-body,#suppliers-modal tbody,#users-modal tbody{display:block!important;width:100%!important;}"
            + "#requests-body tr,#repairs-body tr,#history-body tr,#suppliers-modal tbody tr,#users-modal tbody tr{display:block!important;width:100%!important;margin:0 0 9px!important;padding:12px!important;border:1px solid #dce6ee!important;border-radius:13px!important;background:#fff!important;box-shadow:0 1px 6px rgba(15,23,42,.04)!important;}"
            + "#requests-body td,#repairs-body td,#history-body td,#suppliers-modal tbody td,#users-modal tbody td{display:flex!important;align-items:flex-start!important;justify-content:space-between!important;gap:9px!important;width:100%!important;padding:5px 0!important;border:0!important;text-align:right!important;font-size:11px!important;line-height:1.3!important;white-space:normal!important;word-break:break-word!important;}"
            + "#requests-body td:before,#repairs-body td:before,#history-body td:before,#suppliers-modal tbody td:before,#users-modal tbody td:before{flex:0 0 39%!important;text-align:left!important;color:#71869a!important;font-size:8px!important;font-weight:800!important;text-transform:uppercase!important;letter-spacing:.04em!important;}"
            + "#requests-body td:nth-child(1):before{content:'Data'}#requests-body td:nth-child(2):before{content:'Produto / Material'}#requests-body td:nth-child(3):before{content:'Código Protheus'}#requests-body td:nth-child(4):before{content:'Quantidade'}#requests-body td:nth-child(5):before{content:'Solicitante'}#requests-body td:nth-child(6):before{content:'Status'}"
            + "#repairs-body td:nth-child(1):before{content:'Envio'}#repairs-body td:nth-child(2):before{content:'Mercadoria'}#repairs-body td:nth-child(3):before{content:'Fornecedor'}#repairs-body td:nth-child(4):before{content:'NF saída'}#repairs-body td:nth-child(5):before{content:'Responsável'}#repairs-body td:nth-child(6):before{content:'Status'}#repairs-body td:nth-child(7):before{content:'NF retorno'}#repairs-body td:nth-child(8):before{content:'Retorno'}#repairs-body td:nth-child(9):before{content:'Dias fora'}"
            + "#history-body td:nth-child(1):before{content:'Data / Hora'}#history-body td:nth-child(2):before{content:'Usuário'}#history-body td:nth-child(3):before{content:'Ação'}#history-body td:nth-child(4):before{content:'Registro'}#history-body td:nth-child(5):before{content:'Descrição'}"
            + "#requests-body td:last-child,#repairs-body td:last-child{justify-content:flex-end!important;margin-top:5px!important;padding-top:8px!important;border-top:1px solid #edf2f6!important;}"
            + "#requests-body td:last-child:before,#repairs-body td:last-child:before{display:none!important;}"
            + "#request-form-modal .modal-panel,#repair-form-modal .modal-panel,#repair-detail-modal .modal-panel,#history-detail-modal .modal-panel{background:#f4f8fb!important;}"
            + "#request-form input,#request-form select,#request-form textarea,#repair-form input,#repair-form select,#repair-form textarea{min-height:44px!important;font-size:16px!important;border-radius:10px!important;}"
            + ".android-wa-btn{display:inline-flex!important;align-items:center!important;justify-content:center!important;min-height:36px!important;padding:7px 10px!important;border:1px solid #22c55e!important;border-radius:10px!important;background:#ecfdf5!important;color:#15803d!important;font-weight:800!important;font-size:10px!important;}"
            + ".android-stock-badge{display:inline-flex!important;align-items:center!important;gap:5px!important;margin:2px 0 5px!important;padding:4px 8px!important;border-radius:999px!important;background:#fff7ed!important;color:#c2410c!important;font-size:9px!important;font-weight:800!important;border:1px solid #fed7aa!important;}"
            + "#requests-modal .mb-5.grid,#repairs-modal .mb-5.grid{grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:8px!important;}"
            + "#requests-modal .mb-5.grid>div,#repairs-modal .mb-5.grid>div{padding:10px!important;border-radius:11px!important;}"
            + "#requests-modal .mb-4.flex,#repairs-modal .mb-4.grid{grid-template-columns:1fr!important;display:grid!important;gap:8px!important;}"
            + "#requests-modal input,#requests-modal select,#repairs-modal input,#repairs-modal select{width:100%!important;min-height:42px!important;border-radius:10px!important;font-size:14px!important;}"
            + "#requests-modal button,#repairs-modal button,#history-modal button,#suppliers-modal button,#users-modal button{min-height:38px!important;}"
            + "body{padding-bottom:0!important;}"
            + "}"
            + "@media (min-width:761px){.serra-azul-bf-android-v20{}}";

        String encodedCss = Base64.encodeToString(css.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
        String js = "(function(){try{"
            + "var sid='serra-azul-bf-android-v20';var old=document.getElementById(sid);if(old)old.remove();"
            + "var st=document.createElement('style');st.id=sid;st.textContent=decodeURIComponent(escape(atob('" + encodedCss + "')));document.head.appendChild(st);"
            + "document.documentElement.classList.add('serra-azul-bf-android-v20');"
            + "var meta=document.querySelector('meta[name=viewport]');if(!meta){meta=document.createElement('meta');meta.name='viewport';document.head.appendChild(meta);}meta.setAttribute('content','width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no');"
            + "var title=document.querySelector(\"header.canva-header [data-template-id='page-title']\");if(title)title.textContent='Serra Azul BF — Central de Gestão';"
            + "function wa(){var body=document.getElementById('requests-body');if(!body)return;body.querySelectorAll('tr').forEach(function(tr){var td=tr.querySelectorAll('td');if(td.length<7)return;var action=td[6];if(!action)return;var status=(td[5].innerText||'').trim();if(!/^(Em andamento|Atendida|Finalizada)$/i.test(status))return;if(action.querySelector('.android-wa-btn'))return;var val=function(i){return td[i]?(td[i].innerText||'').trim():''};var msg='📦 SOLICITAÇÃO DE REPOSIÇÃO\\n\\nProduto/Material: '+val(1)+'\\nCódigo Protheus: '+val(2)+'\\nQuantidade: '+val(3)+'\\nSolicitante: '+val(4)+'\\nData: '+val(0)+'\\n\\n⚠️ ESTOQUE BAIXO\\nEste item está chegando ao fim do estoque. Favor providenciar a reposição no TOTVS.';var b=document.createElement('button');b.type='button';b.className='android-wa-btn';b.textContent='WhatsApp';b.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();if(window.SerraAzulAndroid){window.SerraAzulAndroid.sendWhatsApp(msg);}else{window.open('https://wa.me/?text='+encodeURIComponent(msg),'_blank');}});action.appendChild(b);});}"
            + "function badge(){var body=document.getElementById('requests-body');if(!body)return;body.querySelectorAll('tr').forEach(function(tr){if(tr.querySelector('.android-stock-badge'))return;var first=tr.querySelector('td:nth-child(2)');if(!first)return;var b=document.createElement('div');b.className='android-stock-badge';b.textContent='⚠️ Estoque baixo';first.insertBefore(b,first.firstChild);});}"
            + "function refresh(){wa();badge();}refresh();"
            + "var root=document.body;if(root&&!root.dataset.androidV20Observer){root.dataset.androidV20Observer='1';new MutationObserver(function(){refresh();}).observe(root,{childList:true,subtree:true});}"
            + "}catch(e){console.log('SerraAzulBF Android v2.0 UI',e);}})();";
        view.evaluateJavascript(js, null);
    }

    private class WhatsAppBridge {
        @JavascriptInterface
        public void sendWhatsApp(String message) {
            runOnUiThread(() -> {
                try {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_TEXT, message == null ? "" : message);
                    startActivity(Intent.createChooser(send, "Enviar solicitação pelo WhatsApp"));
                } catch (Exception ignored) {
                    try {
                        Uri uri = Uri.parse("https://wa.me/?text=" + Uri.encode(message == null ? "" : message));
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (Exception ignored2) { }
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }
}
