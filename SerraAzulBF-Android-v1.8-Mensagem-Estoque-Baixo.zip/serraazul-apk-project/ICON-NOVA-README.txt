Ícone atualizado para a identidade Serra Azul BF em branco e verde. Versão do app 1.1 / versionCode 2.
