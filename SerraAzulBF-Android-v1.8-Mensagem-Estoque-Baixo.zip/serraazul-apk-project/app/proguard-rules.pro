# Serra Azul BF - no custom shrinking rules required.
