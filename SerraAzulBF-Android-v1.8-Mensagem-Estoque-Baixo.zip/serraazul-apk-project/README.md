# Serra Azul BF — Android WebView

Aplicativo Android do Serra Azul BF.

## v1.5 — Central Clean Mobile (correção real no APK)
- Interface mobile exclusiva do APK, sem alterar o site V14.
- Remove o botão Tela cheia no aplicativo.
- Central compacta e responsiva.
- Indicadores do mês ficam ocultos na entrada e aparecem ao tocar em um mês.
- Consertos e Solicitações usam cartões no celular para evitar tabelas cortadas.
- WhatsApp disponível para Solicitações em andamento, atendidas ou finalizadas.
- Login, Supabase, realtime, permissões e histórico continuam no site carregado pelo WebView.

URL carregada pelo aplicativo:
https://ngcyuri.github.io/serra-azul-bf/
