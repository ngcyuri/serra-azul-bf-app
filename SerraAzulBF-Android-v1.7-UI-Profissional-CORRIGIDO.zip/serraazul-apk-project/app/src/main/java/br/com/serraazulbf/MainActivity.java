package br.com.serraazulbf;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewFeature;

public class MainActivity extends AppCompatActivity {
    private static final String APP_URL = "https://ngcyuri.github.io/serra-azul-bf/";
    private WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(false);
        s.setTextZoom(100);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setUserAgentString(s.getUserAgentString() + " SerraAzulBF-Android/1.7");

        if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            WebSettingsCompat.setForceDark(s, WebSettingsCompat.FORCE_DARK_OFF);
        }

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new WhatsAppBridge(), "SerraAzulAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost();
                if (host != null && (host.equals("ngcyuri.github.io") || host.endsWith("supabase.co") || host.endsWith("supabase.com"))) {
                    return false;
                }
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                injectAppOnlyMobileStyle(view);
            }
        });

        webView.loadUrl(APP_URL);

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack(); else finish();
            }
        });
    }

    /**
     * Ajustes exclusivos do APK. O site publicado no GitHub Pages não é alterado.
     * A tabela de Consertos e Solicitações vira cartão no celular, eliminando
     * a rolagem horizontal e os cabeçalhos cortados.
     */
    private void injectAppOnlyMobileStyle(WebView view) {
        String css = ""
            + "@media (max-width:760px){"
            + "html,body{width:100%!important;max-width:100%!important;min-width:0!important;overflow-x:hidden!important;-webkit-text-size-adjust:100%!important;}"
            + "body{background:#f7f9fb!important;}"
            + "#fullscreen-btn{display:none!important;}"
            + "header.canva-header{padding:10px 12px 12px!important;background:#fff!important;}"
            + "header.canva-header>.mx-auto{width:100%!important;max-width:none!important;display:grid!important;grid-template-columns:1fr!important;gap:9px!important;}"
            + "header.canva-header .brand-title{display:grid!important;grid-template-columns:auto minmax(0,1fr)!important;align-items:center!important;gap:9px!important;min-width:0!important;}"
            + "header.canva-header .brand-logo{width:92px!important;max-width:92px!important;max-height:42px!important;object-fit:contain!important;}"
            + "header.canva-header .brand-divider{height:34px!important;}"
            + "header.canva-header h1{font-size:18px!important;line-height:1.12!important;margin:0!important;word-break:normal!important;overflow-wrap:normal!important;}"
            + "header.canva-header p{display:none!important;}"
            + "header.canva-header .header-actions{display:grid!important;grid-template-columns:minmax(0,1fr) auto!important;gap:7px!important;width:100%!important;}"
            + "#user-area{display:flex!important;width:100%!important;min-width:0!important;}"
            + "#user-badge{width:100%!important;max-width:none!important;min-width:0!important;padding:6px 8px!important;}"
            + "#user-email{font-size:11px!important;max-width:none!important;min-width:0!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important;}"
            + "#user-role{display:none!important;}"
            + "#logout-btn{min-height:40px!important;padding:8px 11px!important;font-size:12px!important;white-space:nowrap!important;}"
            + "main.mx-auto{width:100%!important;max-width:none!important;padding:12px!important;margin:0!important;}"
            + "#tabs-container{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:8px!important;width:100%!important;border:0!important;padding:0!important;margin:0!important;overflow:visible!important;}"
            + "#tabs-container>button{width:100%!important;min-width:0!important;min-height:48px!important;margin:0!important;padding:9px 7px!important;border-radius:13px!important;justify-content:center!important;font-size:13px!important;line-height:1.15!important;white-space:normal!important;}"
            + "#tabs-container>button:nth-child(1),#tabs-container>button:nth-child(2){grid-column:span 2!important;}"
            + "#tabs-container>button:nth-child(1),#tabs-container>button:nth-child(2){min-height:46px!important;}"
            + "#tabs-container>button[data-month]{min-height:62px!important;font-size:14px!important;font-weight:800!important;background:#fff!important;color:#64748b!important;border:1px solid #dbe2e8!important;box-shadow:0 1px 3px rgba(15,23,42,.04)!important;}"
            + "#tabs-container>button[data-month].tab-active{background:#1f4569!important;color:#fff!important;border-color:#1f4569!important;box-shadow:0 4px 12px rgba(31,69,105,.16)!important;}"
            + "#tabs-container>button[data-template-id='new-month-btn'],#tabs-container>button[data-template-id='edit-month-btn'],#tabs-container>button[data-template-id='suppliers-btn'],#tabs-container>button[data-template-id='users-btn'],#tabs-container>button[onclick*='openRequestsModal'],#tabs-container>button[onclick*='openRepairsModal'],#tabs-container>button[data-template-id='history-btn']{font-size:12px!important;font-weight:750!important;}"
            + "#summary-cards{display:none!important;width:100%!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:8px!important;margin:14px 0 0!important;}"
            + "#summary-cards.android-month-open{display:grid!important;}"
            + "#summary-cards .card-stat{min-width:0!important;padding:12px!important;border-radius:14px!important;box-shadow:none!important;border-color:#dbe2e8!important;background:#fff!important;}"
            + "#summary-cards .card-stat p:first-child{font-size:9px!important;line-height:1.2!important;letter-spacing:.06em!important;}"
            + "#summary-cards .card-stat p:last-child{font-size:22px!important;line-height:1.1!important;margin-top:3px!important;}"
            + "#app-mobile-section-label{display:block!important;margin:4px 2px 2px!important;font-size:10px!important;font-weight:800!important;letter-spacing:.08em!important;text-transform:uppercase!important;color:#64748b!important;}"
            + "#app-mobile-summary-label{display:none!important;margin:14px 2px 2px!important;font-size:10px!important;font-weight:800!important;letter-spacing:.08em!important;text-transform:uppercase!important;color:#64748b!important;}"
            + "#app-mobile-summary-label.android-month-open{display:block!important;}"
            + "main>.filter-grid,main>section[aria-label='Pedidos de compra'],#orders-toggle-wrap{display:none!important;}"
            + "main>.filter-grid.android-orders-open,main>section[aria-label='Pedidos de compra'].android-orders-open,#orders-toggle-wrap.android-orders-open{display:block!important;}"
            + ".filter-grid.android-orders-open{display:grid!important;grid-template-columns:1fr!important;gap:8px!important;padding:10px!important;border:1px solid #e2e8f0!important;border-radius:14px!important;background:#fff!important;margin-top:12px!important;}"
            + ".filter-grid.android-orders-open>*{width:100%!important;min-width:0!important;}"
            + ".filter-grid.android-orders-open input,.filter-grid.android-orders-open select,.filter-grid.android-orders-open button{width:100%!important;min-height:44px!important;box-sizing:border-box!important;}"
            + "main>section[aria-label='Pedidos de compra'].android-orders-open{margin-top:10px!important;border-radius:14px!important;box-shadow:none!important;}"
            + "#orders-table{width:100%!important;min-width:0!important;display:block!important;}"
            + "#orders-table thead{display:none!important;}"
            + "#orders-table tbody,#orders-table tbody tr,#orders-table tbody td{display:block!important;width:100%!important;box-sizing:border-box!important;}"
            + "#orders-table tbody tr{margin:0 0 9px!important;padding:8px 12px!important;border:1px solid #e2e8f0!important;border-radius:13px!important;background:#fff!important;}"
            + "#orders-table tbody td{display:flex!important;justify-content:space-between!important;gap:10px!important;padding:6px 0!important;border:0!important;text-align:right!important;font-size:12px!important;white-space:normal!important;word-break:break-word!important;}"
            + "#orders-table tbody td:before{flex:0 0 40%!important;text-align:left!important;color:#64748b!important;font-size:9px!important;font-weight:800!important;text-transform:uppercase!important;letter-spacing:.04em!important;}"
            + "#orders-table tbody td:nth-child(1):before{content:'Fornecedor';}#orders-table tbody td:nth-child(2):before{content:'Orçamento';}#orders-table tbody td:nth-child(3):before{content:'Recebido';}#orders-table tbody td:nth-child(4):before{content:'Pedido';}#orders-table tbody td:nth-child(5):before{content:'Dia feito';}#orders-table tbody td:nth-child(6):before{content:'Status';}"
            + "#orders-table tbody td:nth-child(7){justify-content:flex-end!important;margin-top:4px!important;padding-top:8px!important;border-top:1px solid #f1f5f9!important;}#orders-table tbody td:nth-child(7):before{display:none!important;}"
            + ".modal-overlay{padding:8px!important;align-items:flex-start!important;}"
            + ".modal-panel{width:100%!important;max-width:none!important;max-height:calc(100vh - 16px)!important;overflow:auto!important;border-radius:16px!important;padding:14px!important;}"
            + ".modal-panel input,.modal-panel select,.modal-panel textarea{max-width:100%!important;box-sizing:border-box!important;min-height:44px!important;}"
            + "#requests-modal .responsive-table,#repairs-modal .responsive-table{width:100%!important;max-width:100%!important;overflow:visible!important;border:0!important;background:transparent!important;}"
            + "#requests-modal .responsive-table table,#repairs-modal .responsive-table table{width:100%!important;min-width:0!important;display:block!important;border:0!important;}"
            + "#requests-modal .responsive-table thead,#repairs-modal .responsive-table thead{display:none!important;}"
            + "#requests-modal .responsive-table tbody,#repairs-modal .responsive-table tbody{display:block!important;width:100%!important;}"
            + "#requests-modal .responsive-table tbody tr,#repairs-modal .responsive-table tbody tr{display:block!important;width:100%!important;margin:0 0 10px!important;padding:11px 12px!important;border:1px solid #e2e8f0!important;border-radius:14px!important;background:#fff!important;box-shadow:0 2px 8px rgba(15,23,42,.05)!important;}"
            + "#requests-modal .responsive-table tbody td,#repairs-modal .responsive-table tbody td{display:flex!important;align-items:flex-start!important;justify-content:space-between!important;gap:10px!important;width:100%!important;padding:6px 0!important;border:0!important;text-align:right!important;font-size:12px!important;line-height:1.35!important;white-space:normal!important;word-break:break-word!important;}"
            + "#requests-modal .responsive-table tbody td:before,#repairs-modal .responsive-table tbody td:before{flex:0 0 38%!important;text-align:left!important;color:#64748b!important;font-size:9px!important;font-weight:800!important;text-transform:uppercase!important;letter-spacing:.04em!important;}"
            + "#requests-modal .responsive-table tbody td:nth-child(1):before{content:'Data';}#requests-modal .responsive-table tbody td:nth-child(2):before{content:'Produto / Material';}#requests-modal .responsive-table tbody td:nth-child(3):before{content:'Código Protheus';}#requests-modal .responsive-table tbody td:nth-child(4):before{content:'Quantidade';}#requests-modal .responsive-table tbody td:nth-child(5):before{content:'Solicitante';}#requests-modal .responsive-table tbody td:nth-child(6):before{content:'Status';}"
            + "#requests-modal .responsive-table tbody td:nth-child(7){justify-content:flex-end!important;margin-top:4px!important;padding-top:8px!important;border-top:1px solid #f1f5f9!important;}#requests-modal .responsive-table tbody td:nth-child(7):before{display:none!important;}"
            + "#repairs-modal .responsive-table tbody td:nth-child(1):before{content:'Envio';}#repairs-modal .responsive-table tbody td:nth-child(2):before{content:'Mercadoria';}#repairs-modal .responsive-table tbody td:nth-child(3):before{content:'Fornecedor';}#repairs-modal .responsive-table tbody td:nth-child(4):before{content:'NF saída';}#repairs-modal .responsive-table tbody td:nth-child(5):before{content:'Responsável';}#repairs-modal .responsive-table tbody td:nth-child(6):before{content:'Status';}#repairs-modal .responsive-table tbody td:nth-child(7):before{content:'NF retorno';}#repairs-modal .responsive-table tbody td:nth-child(8):before{content:'Retorno';}#repairs-modal .responsive-table tbody td:nth-child(9):before{content:'Dias fora';}"
            + "#repairs-modal .responsive-table tbody td:nth-child(10){justify-content:flex-end!important;margin-top:4px!important;padding-top:8px!important;border-top:1px solid #f1f5f9!important;}#repairs-modal .responsive-table tbody td:nth-child(10):before{display:none!important;}"
            + "#requests-modal .mb-5.grid,#repairs-modal .mb-5.grid{grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:8px!important;}"
            + "#requests-modal .mb-4.flex,#repairs-modal .mb-4.grid{grid-template-columns:1fr!important;gap:8px!important;}"
            + "#requests-modal .mb-4.flex>* ,#repairs-modal .mb-4.grid>*{width:100%!important;min-width:0!important;}"
            + "#request-form-modal .modal-panel,#repair-form-modal .modal-panel{padding:14px!important;}"
            + "}"
            + "@media (prefers-reduced-motion: reduce){*{transition:none!important;scroll-behavior:auto!important;}}";

        String encoded = Base64.encodeToString(css.getBytes(java.nio.charset.StandardCharsets.UTF_8), Base64.NO_WRAP);
        String js = "(function(){try{"
            + "var id='serra-azul-bf-android-mobile-css';var old=document.getElementById(id);if(old)old.remove();"
            + "var s=document.createElement('style');s.id=id;s.textContent=decodeURIComponent(escape(atob('" + encoded + "')));document.head.appendChild(s);"
            + "document.documentElement.classList.add('serra-azul-bf-android');"
            + "var tabs=document.getElementById('tabs-container');if(!tabs)return;"
            + "var label=document.getElementById('app-mobile-section-label');if(!label){label=document.createElement('div');label.id='app-mobile-section-label';tabs.parentNode.insertBefore(label,tabs);}label.textContent='MÊS E MÓDULOS';"
            + "var sl=document.getElementById('app-mobile-summary-label');if(!sl){sl=document.createElement('div');sl.id='app-mobile-summary-label';var sc=document.getElementById('summary-cards');if(sc)sc.parentNode.insertBefore(sl,sc);}sl.textContent='INDICADORES DO MÊS';"
            + "var summary=document.getElementById('summary-cards');"
            + "var filter=document.querySelector('main>.filter-grid');var orderSection=document.querySelector('main>section[aria-label=\"Pedidos de compra\"]');var ordersToggle=document.getElementById('orders-toggle-wrap');"
            + "function openMonth(){if(summary){summary.classList.add('android-month-open');}if(sl)sl.classList.add('android-month-open');if(filter)filter.classList.add('android-orders-open');if(orderSection)orderSection.classList.add('android-orders-open');if(ordersToggle)ordersToggle.classList.add('android-orders-open');}"
            + "function bind(){tabs.querySelectorAll('button[data-month]').forEach(function(btn){if(btn.dataset.androidBound==='1')return;btn.dataset.androidBound='1';btn.addEventListener('click',openMonth);});"
            + "tabs.querySelectorAll('button[onclick*=\"openRequestsModal\"],button[onclick*=\"openRepairsModal\"]').forEach(function(btn){if(btn.dataset.androidBoundModule==='1')return;btn.dataset.androidBoundModule='1';btn.addEventListener('click',function(){setTimeout(function(){fixTables();addWhatsApp();},120);});});}"
            + "function fixTables(){['requests-modal','repairs-modal'].forEach(function(mid){var m=document.getElementById(mid);if(!m)return;var table=m.querySelector('.responsive-table table');if(table){table.style.minWidth='0px';table.style.width='100%';}var wrap=m.querySelector('.responsive-table');if(wrap){wrap.style.overflow='visible';wrap.style.width='100%';}});}"
            + "function addWhatsApp(){var body=document.querySelector('#requests-modal #requests-body');if(!body)return;body.querySelectorAll('tr').forEach(function(tr){var td=tr.querySelectorAll('td');if(td.length<7)return;var status=(td[5].innerText||'').trim();if(!/^(Em andamento|Atendida|Finalizada)$/i.test(status))return;var action=td[6];if(!action||action.querySelector('.android-wa-btn'))return;var val=function(i){return td[i]?(td[i].innerText||'').trim():''};var msg='📦 SOLICITAÇÃO\\n\\nProduto: '+val(1)+'\\nCódigo Protheus: '+val(2)+'\\nQuantidade: '+val(3)+'\\nSolicitante: '+val(4)+'\\nData: '+val(0)+'\\n\\n⚠️ Solicitação em andamento. Favor realizar o pedido no TOTVS.';var b=document.createElement('button');b.className='android-wa-btn';b.type='button';b.textContent='📱 WhatsApp';b.style.cssText='margin-left:6px;min-height:40px;padding:8px 10px;border:1px solid #16a34a;border-radius:9px;background:#f0fdf4;color:#15803d;font-weight:800;cursor:pointer;';b.onclick=function(e){e.preventDefault();e.stopPropagation();if(window.SerraAzulAndroid)window.SerraAzulAndroid.sendWhatsApp(msg);};action.appendChild(b);});}"
            + "if(summary)summary.classList.remove('android-month-open');if(sl)sl.classList.remove('android-month-open');bind();fixTables();addWhatsApp();"
            + "if(!tabs.dataset.androidObserver){tabs.dataset.androidObserver='1';new MutationObserver(function(){bind();fixTables();addWhatsApp();}).observe(tabs,{childList:true,subtree:true});}"
            + "var req=document.getElementById('requests-modal');if(req&&!req.dataset.androidObserver){req.dataset.androidObserver='1';new MutationObserver(function(){fixTables();addWhatsApp();}).observe(req,{childList:true,subtree:true});}"
            + "var rep=document.getElementById('repairs-modal');if(rep&&!rep.dataset.androidObserver){rep.dataset.androidObserver='1';new MutationObserver(function(){fixTables();}).observe(rep,{childList:true,subtree:true});}"
            + "}catch(e){console.log('SerraAzul Android UI:',e);}})();";
        view.evaluateJavascript(js, null);
    }

    /** Ponte nativa usada somente pelo APK para abrir o compartilhamento do WhatsApp. */
    private class WhatsAppBridge {
        @JavascriptInterface
        public void sendWhatsApp(String message) {
            runOnUiThread(() -> {
                try {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_TEXT, message == null ? "" : message);
                    Intent chooser = Intent.createChooser(send, "Enviar solicitação pelo WhatsApp");
                    startActivity(chooser);
                } catch (Exception ignored) {
                    try {
                        Uri uri = Uri.parse("https://wa.me/?text=" + Uri.encode(message == null ? "" : message));
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (Exception ignored2) {}
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }
}
