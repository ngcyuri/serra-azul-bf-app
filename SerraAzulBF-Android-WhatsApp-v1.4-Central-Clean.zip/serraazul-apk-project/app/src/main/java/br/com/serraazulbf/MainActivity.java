package br.com.serraazulbf;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewFeature;

public class MainActivity extends AppCompatActivity {
    private static final String APP_URL = "https://ngcyuri.github.io/serra-azul-bf/";
    private WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(false);
        s.setTextZoom(100);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setUserAgentString(s.getUserAgentString() + " SerraAzulBF-Android/1.4");

        if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            WebSettingsCompat.setForceDark(s, WebSettingsCompat.FORCE_DARK_OFF);
        }

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new WhatsAppBridge(), "SerraAzulAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost();
                if (host != null && (host.equals("ngcyuri.github.io") || host.endsWith("supabase.co") || host.endsWith("supabase.com"))) {
                    return false;
                }
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                injectAppOnlyMobileStyle(view);
            }
        });

        webView.loadUrl(APP_URL);

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack(); else finish();
            }
        });
    }

    /**
     * Ajustes exclusivos do APK. O site publicado no GitHub Pages não é alterado.
     * A tabela de Consertos e Solicitações vira cartão no celular, eliminando
     * a rolagem horizontal e os cabeçalhos cortados.
     */
    private void injectAppOnlyMobileStyle(WebView view) {
        String css = ""
            + "@media (max-width:760px){"
            // Cabeçalho compacto e sem quebra letra por letra.
            + "header.canva-header .mx-auto{flex-wrap:wrap!important;align-items:center!important;}"
            + "header.canva-header .brand-title{flex:1 1 100%!important;width:100%!important;max-width:100%!important;min-width:0!important;}"
            + "header.canva-header .brand-title>div{min-width:0!important;flex:1 1 auto!important;}"
            + "header.canva-header .brand-title h1{font-size:20px!important;line-height:1.15!important;word-break:normal!important;overflow-wrap:normal!important;white-space:normal!important;}"
            + "header.canva-header .brand-title p{font-size:12px!important;line-height:1.35!important;}"
            + "header.canva-header .header-actions{width:100%!important;display:flex!important;justify-content:flex-end!important;margin-left:0!important;}"

            // Modais dos dois módulos.
            + "#requests-modal .modal-panel,#repairs-modal .modal-panel,#repair-detail-modal .modal-panel,#request-form-modal .modal-panel,#repair-form-modal .modal-panel{padding:14px!important;max-width:100%!important;}"
            + "#requests-modal .mb-5.grid,#repairs-modal .mb-5.grid{grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:8px!important;}"
            + "#requests-modal .mb-5.grid>div,#repairs-modal .mb-5.grid>div{padding:10px!important;min-width:0!important;}"
            + "#requests-modal .mb-5.grid .text-2xl,#repairs-modal .mb-5.grid .text-2xl{font-size:20px!important;}"
            + "#requests-modal .mb-5.grid .text-xs,#repairs-modal .mb-5.grid .text-xs{font-size:9px!important;line-height:1.25!important;}"
            + "#requests-modal .mb-4.flex,#repairs-modal .mb-4.grid{display:grid!important;grid-template-columns:1fr!important;gap:8px!important;}"
            + "#requests-modal .mb-4.flex>* ,#repairs-modal .mb-4.grid>*{width:100%!important;min-width:0!important;}"
            + "#requests-modal .mb-4.flex button,#repairs-modal .mb-4.grid button{min-height:44px!important;justify-content:center!important;}"

            // Solicitações: tabela -> cartões.
            + "#requests-modal .responsive-table{overflow:visible!important;border:0!important;margin-top:6px!important;}"
            + "#requests-modal table{width:100%!important;min-width:0!important;border-collapse:separate!important;}"
            + "#requests-modal thead{display:none!important;}"
            + "#requests-modal #requests-body{display:block!important;width:100%!important;}"
            + "#requests-modal #requests-body tr{display:block!important;width:100%!important;margin:0 0 10px!important;padding:11px 12px!important;border:1px solid #e2e8f0!important;border-radius:13px!important;background:#fff!important;box-shadow:0 2px 8px rgba(15,23,42,.055)!important;}"
            + "#requests-modal #requests-body td{display:flex!important;align-items:flex-start!important;justify-content:space-between!important;gap:10px!important;width:100%!important;min-height:0!important;padding:6px 0!important;border:0!important;text-align:right!important;font-size:13px!important;line-height:1.35!important;white-space:normal!important;word-break:break-word!important;}"
            + "#requests-modal #requests-body td:before{flex:0 0 39%!important;text-align:left!important;color:#64748b!important;font-size:9px!important;font-weight:800!important;text-transform:uppercase!important;letter-spacing:.045em!important;}"
            + "#requests-modal #requests-body td:nth-child(1):before{content:'Data'}"
            + "#requests-modal #requests-body td:nth-child(2):before{content:'Produto / Material'}"
            + "#requests-modal #requests-body td:nth-child(3):before{content:'Código Protheus'}"
            + "#requests-modal #requests-body td:nth-child(4):before{content:'Quantidade'}"
            + "#requests-modal #requests-body td:nth-child(5):before{content:'Solicitante'}"
            + "#requests-modal #requests-body td:nth-child(6):before{content:'Status'}"
            + "#requests-modal #requests-body td:nth-child(7){margin-top:5px!important;padding-top:9px!important;border-top:1px solid #f1f5f9!important;justify-content:flex-end!important;}"
            + "#requests-modal #requests-body td:nth-child(7):before{display:none!important;}"
            + "#requests-modal #requests-body td:nth-child(7) button{min-width:40px!important;min-height:40px!important;margin-left:5px!important;}"

            // Consertos: tabela -> cartões.
            + "#repairs-modal .responsive-table{overflow:visible!important;border:0!important;margin-top:6px!important;}"
            + "#repairs-modal table{width:100%!important;min-width:0!important;border-collapse:separate!important;}"
            + "#repairs-modal thead{display:none!important;}"
            + "#repairs-modal #repairs-body{display:block!important;width:100%!important;}"
            + "#repairs-modal #repairs-body tr{display:block!important;width:100%!important;margin:0 0 11px!important;padding:11px 12px!important;border:1px solid #e2e8f0!important;border-radius:13px!important;background:#fff!important;box-shadow:0 2px 8px rgba(15,23,42,.055)!important;}"
            + "#repairs-modal #repairs-body td{display:flex!important;align-items:flex-start!important;justify-content:space-between!important;gap:10px!important;width:100%!important;min-height:0!important;padding:6px 0!important;border:0!important;text-align:right!important;font-size:13px!important;line-height:1.35!important;white-space:normal!important;word-break:break-word!important;}"
            + "#repairs-modal #repairs-body td:before{flex:0 0 38%!important;text-align:left!important;color:#64748b!important;font-size:9px!important;font-weight:800!important;text-transform:uppercase!important;letter-spacing:.045em!important;}"
            + "#repairs-modal #repairs-body td:nth-child(1):before{content:'Envio'}"
            + "#repairs-modal #repairs-body td:nth-child(2):before{content:'Mercadoria'}"
            + "#repairs-modal #repairs-body td:nth-child(3):before{content:'Fornecedor'}"
            + "#repairs-modal #repairs-body td:nth-child(4):before{content:'NF saída'}"
            + "#repairs-modal #repairs-body td:nth-child(5):before{content:'Responsável'}"
            + "#repairs-modal #repairs-body td:nth-child(6):before{content:'Status'}"
            + "#repairs-modal #repairs-body td:nth-child(7):before{content:'NF retorno'}"
            + "#repairs-modal #repairs-body td:nth-child(8):before{content:'Retorno'}"
            + "#repairs-modal #repairs-body td:nth-child(9):before{content:'Dias fora'}"
            + "#repairs-modal #repairs-body td:nth-child(10){margin-top:5px!important;padding-top:9px!important;border-top:1px solid #f1f5f9!important;justify-content:flex-end!important;}"
            + "#repairs-modal #repairs-body td:nth-child(10):before{display:none!important;}"
            + "#repairs-modal #repairs-body td:nth-child(10) button{min-width:40px!important;min-height:40px!important;margin-left:5px!important;}"
            + "#requests-modal #requests-body td:nth-child(2),#repairs-modal #repairs-body td:nth-child(2){font-weight:700!important;color:#0f172a!important;}"
            + "#repairs-modal #repairs-body td:nth-child(9){font-weight:800!important;}"

            // Formulários confortáveis no celular.
            + "#request-form-modal form,#repair-form-modal form{display:grid!important;grid-template-columns:1fr!important;gap:11px!important;}"
            + "#request-form-modal form>div,#repair-form-modal form>div{grid-column:1/-1!important;}"
            + "#request-form-modal input,#request-form-modal select,#request-form-modal textarea,#repair-form-modal input,#repair-form-modal select,#repair-form-modal textarea{min-height:46px!important;font-size:16px!important;max-width:100%!important;}"
            + "#request-form-modal textarea,#repair-form-modal textarea{min-height:88px!important;}"
            + "#request-form-modal form>div:last-child,#repair-form-modal form>div:last-child{display:grid!important;grid-template-columns:1fr 1fr!important;gap:8px!important;}"
            + "#request-form-modal form>div:last-child button,#repair-form-modal form>div:last-child button{width:100%!important;min-height:46px!important;margin:0!important;}"
            + "}"
            + "/* CENTRAL CLEAN — somente no APK */"
            + "@media (max-width:760px){"
            + "#fullscreen-btn{display:none!important;}"
            + "header.canva-header{padding:10px 12px!important;}"
            + "header.canva-header .mx-auto{gap:8px!important;}"
            + "header.canva-header .brand-logo img,header.canva-header img{max-height:58px!important;width:auto!important;}"
            + "header.canva-header .brand-title{flex:1 1 0!important;width:auto!important;max-width:none!important;}"
            + "header.canva-header .brand-title h1{font-size:18px!important;line-height:1.12!important;margin:0!important;letter-spacing:-.02em!important;}"
            + "header.canva-header .brand-title p{display:none!important;}"
            + "header.canva-header .header-actions{width:auto!important;flex:0 0 auto!important;margin:0!important;}"
            + "#user-area{gap:6px!important;}"
            + "#user-badge{max-width:205px!important;padding:7px 10px!important;}"
            + "#user-email{font-size:11px!important;max-width:135px!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important;}"
            + "#logout-btn{padding:8px 10px!important;font-size:12px!important;}"
            + "main.mx-auto.max-w-7xl{padding:12px!important;}"
            + "#tabs-container{gap:8px!important;margin-bottom:12px!important;}"
            + "#tabs-container>button:not([data-month]){padding:10px 9px!important;font-size:12px!important;min-height:42px!important;}"
            + "#tabs-container>button[data-month]{padding:10px 8px!important;font-size:12px!important;min-height:44px!important;border-radius:11px!important;flex:1 1 calc(50% - 8px)!important;justify-content:center!important;}"
            + "#tabs-container>button[data-template-id='new-month-btn'],#tabs-container>button[data-template-id='edit-month-btn'],#tabs-container>button[data-template-id='suppliers-btn'],#tabs-container>button[data-template-id='users-btn'],#tabs-container>button[data-template-id='history-btn']{font-size:11px!important;padding:9px 7px!important;min-height:40px!important;}"
            + "#summary-cards{display:none!important;opacity:0;transform:translateY(6px);transition:opacity .22s ease,transform .22s ease;}"
            + "#summary-cards.android-month-open{display:grid!important;opacity:1;transform:translateY(0);margin:0 0 12px!important;gap:8px!important;}"
            + "#summary-cards .card-stat{padding:10px!important;border-width:1px!important;border-radius:12px!important;box-shadow:none!important;}"
            + "#summary-cards .card-stat p:first-child{font-size:9px!important;letter-spacing:.08em!important;}"
            + "#summary-cards .card-stat p:last-child{font-size:21px!important;margin-top:2px!important;}"
            + "#summary-cards::before{content:'Indicadores do mês';grid-column:1/-1;font-size:11px;font-weight:800;color:#64748b;text-transform:uppercase;letter-spacing:.08em;margin:2px 2px 0;}"
            + "#tabs-container::before{content:'Mês';width:100%;display:block;font-size:11px;font-weight:800;color:#64748b;text-transform:uppercase;letter-spacing:.08em;margin:2px 2px 0;}"
            + "#tabs-container>button[onclick^='openDashboardModal'],#tabs-container>button[onclick^='openReportsModal']{flex:1 1 calc(50% - 8px)!important;}"
            + "#tabs-container>button[onclick^='openMonthModal'],#tabs-container>button[onclick^='openEditMonthModal'],#tabs-container>button[onclick^='openSuppliersModal'],#tabs-container>button[onclick^='openUsersModal'],#tabs-container>button[onclick^='openHistoryModal']{flex:1 1 calc(50% - 8px)!important;}"
            + "#tabs-container>button[onclick^='openRequestsModal'],#tabs-container>button[onclick^='openRepairsModal']{flex:1 1 calc(50% - 8px)!important;min-height:46px!important;font-size:13px!important;}"
            + "#tabs-container>button[data-month].tab-active{box-shadow:0 2px 8px rgba(15,23,42,.08)!important;}"
            + "#tabs-container>button[data-month].tab-inactive{background:#fff!important;border:1px solid #e2e8f0!important;color:#64748b!important;}"
            + "#sync-status{font-size:10px!important;}"
            + "}"
            + "@media (prefers-reduced-motion: reduce){*{scroll-behavior:auto!important;transition:none!important;}}";

        String encoded = Base64.encodeToString(css.getBytes(java.nio.charset.StandardCharsets.UTF_8), Base64.NO_WRAP);
        String js = "(function(){try{var id='serra-azul-bf-android-mobile-css';var old=document.getElementById(id);if(old)old.remove();var s=document.createElement('style');s.id=id;s.textContent=atob('"
                + encoded
                + "');document.head.appendChild(s);document.documentElement.classList.add('serra-azul-bf-android');"
                + ""
                + "var summary=document.getElementById('summary-cards');"
                + "var monthBtns=document.querySelectorAll('#tabs-container button[data-month]');"
                + "monthBtns.forEach(function(btn){if(btn.dataset.androidBound)return;btn.dataset.androidBound='1';btn.addEventListener('click',function(){if(summary){summary.classList.remove('android-month-open');void summary.offsetWidth;summary.classList.add('android-month-open');}});});"
                + "if(summary)summary.classList.remove('android-month-open');"
                + ""
                + + "var buildMsg=function(tr){try{"
                + "var td=tr.querySelectorAll('td');"
                + "var v=function(i){return td[i]?td[i].innerText.trim():''};"
                + "var status=v(5);"
                + "if(!/^(Em andamento|Atendida|Finalizada)$/i.test(status))return null;"
                + "var produto=v(1), codigo=v(2), qtd=v(3), solicitante=v(4), data=v(0);"
                + "var obs='';"
                + "var text='📦 NOVA SOLICITAÇÃO\n\nProduto: '+produto+'\nCódigo Protheus: '+codigo+'\nQuantidade: '+qtd+'\nSolicitante: '+solicitante+'\nData: '+data;"
                + "if(obs)text+='\nObservação: '+obs;"
                + "text+='\n\n⚠️ Solicitação em andamento. Favor realizar o pedido no TOTVS.';"
                + "return text;"
                + "}catch(e){return null}};"
                + "var add=function(){var body=document.querySelector('#requests-modal #requests-body');if(!body)return;body.querySelectorAll('tr').forEach(function(tr){var cells=tr.querySelectorAll('td');if(cells.length<7)return;var action=cells[6];if(action.querySelector('.android-wa-btn'))return;var msg=buildMsg(tr);if(!msg)return;var b=document.createElement('button');b.className='android-wa-btn';b.type='button';b.innerHTML='📱 WhatsApp';b.title='Enviar esta solicitação pelo WhatsApp';b.style.cssText='margin-left:8px!important;min-height:40px!important;padding:8px 12px!important;border:1px solid #16a34a!important;border-radius:9px!important;background:#f0fdf4!important;color:#15803d!important;font-weight:800!important;cursor:pointer!important;';b.onclick=function(e){e.preventDefault();e.stopPropagation();window.SerraAzulAndroid.sendWhatsApp(msg)};action.appendChild(b);});};"
                + "add();var mo=new MutationObserver(function(){add()});var root=document.querySelector('#requests-modal');if(root)mo.observe(root,{childList:true,subtree:true});"
                + "}catch(e){}})();";
        view.evaluateJavascript(js, null);
    }

    /** Ponte nativa usada somente pelo APK para abrir o compartilhamento do WhatsApp. */
    private class WhatsAppBridge {
        @JavascriptInterface
        public void sendWhatsApp(String message) {
            runOnUiThread(() -> {
                try {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_TEXT, message == null ? "" : message);
                    Intent chooser = Intent.createChooser(send, "Enviar solicitação pelo WhatsApp");
                    startActivity(chooser);
                } catch (Exception ignored) {
                    try {
                        Uri uri = Uri.parse("https://wa.me/?text=" + Uri.encode(message == null ? "" : message));
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (Exception ignored2) {}
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }
}
